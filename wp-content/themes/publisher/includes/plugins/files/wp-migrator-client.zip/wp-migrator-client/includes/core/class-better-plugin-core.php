<?php

/**
 * Better Studio Plugin Core
 *
 * @since     1.0.0
 *
 * @package   Better_Plugin_Core
 * @author    BetterStudio <info@betterstudio.com>
 * @link      http://www.betterstudio.com
 *
 * @version   1.0.0
 */


if ( ! class_exists( 'Better_Plugin_Core' ) ) {

	class Better_Plugin_Core {

	}
}

