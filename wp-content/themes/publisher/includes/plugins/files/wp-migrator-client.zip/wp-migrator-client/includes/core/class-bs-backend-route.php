<?php


if ( ! class_exists( 'BS_Backend_Route' ) ) {

	class BS_Backend_Route {


	}
}
