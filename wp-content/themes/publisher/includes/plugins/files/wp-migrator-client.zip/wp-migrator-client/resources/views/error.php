<div id="wp-migrator-panel" class="wp-migrator-panel">

	<div id="wpmg-container" style="min-height: 50px;display: none;">

		<div class="error wp-migrator-support-error">
			<h2><?php echo $error ?></h2>

			<?php if ( $description ) : ?>
				<div class="description">
					<p>
						<?php echo $description ?>
					</p>
				</div>
			<?php endif ?>
		</div>

	</div>
</div>