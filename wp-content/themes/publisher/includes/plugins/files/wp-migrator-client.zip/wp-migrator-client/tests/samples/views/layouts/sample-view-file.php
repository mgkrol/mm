<?php

echo 'view';

if ( ! empty( $var1 ) ) {
	echo $var1;
}

if ( ! empty( $var2 ) ) {
	echo $var2;
}

