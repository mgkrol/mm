<?php

return array(

	'id'         => Better_Social_Counter::get_option( 'flickr_group' ),
	'name'       => Better_Social_Counter::get_option( 'flickr_name' ),
	'title'      => Better_Social_Counter::get_option( 'flickr_title' ),
	'button'     => Better_Social_Counter::get_option( 'flickr_button' ),
	'title_join' => Better_Social_Counter::get_option( 'flickr_title_join' ),
);
