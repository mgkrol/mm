<?php

return array(

	'name'       => Better_Social_Counter::get_option( 'comments_name' ),
	'title'      => Better_Social_Counter::get_option( 'comments_title' ),
	'title_join' => Better_Social_Counter::get_option( 'comments_title_join' ),
);
