<?php

return array(

	'link'       => Better_Social_Counter::get_option( 'ok_ru_link' ),
	'name'       => Better_Social_Counter::get_option( 'ok_ru_name' ),
	'title'      => Better_Social_Counter::get_option( 'ok_ru_title' ),
	'button'     => Better_Social_Counter::get_option( 'ok_ru_button' ),
	'title_join' => Better_Social_Counter::get_option( 'ok_ru_title_join' ),
);
