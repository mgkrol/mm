<?php

return array(

	'name'       => Better_Social_Counter::get_option( 'posts_name' ),
	'title'      => Better_Social_Counter::get_option( 'posts_title' ),
	'title_join' => Better_Social_Counter::get_option( 'posts_title_join' ),
);
