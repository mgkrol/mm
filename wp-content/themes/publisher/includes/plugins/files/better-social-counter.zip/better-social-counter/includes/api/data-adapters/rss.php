<?php

return array(

	'type'       => Better_Social_Counter::get_option( 'rss_type' ),
	'link'       => Better_Social_Counter::get_option( 'rss_type_custom' ),
	'category'   => Better_Social_Counter::get_option( 'rss_type_category' ),
	'name'       => Better_Social_Counter::get_option( 'rss_name' ),
	'title'      => Better_Social_Counter::get_option( 'rss_title' ),
	'button'     => Better_Social_Counter::get_option( 'rss_button' ),
	'title_join' => Better_Social_Counter::get_option( 'rss_title_join' ),
);
