<?php

add_filter( 'better-framework/panel/add', 'bs_financial_panel_add', 10 );

if ( ! function_exists( 'bs_financial_panel_add' ) ) {
	/**
	 * Callback: Ads panel
	 *
	 * Filter: better-framework/panel/options
	 *
	 * @param $panels
	 *
	 * @return array
	 */
	function bs_financial_panel_add( $panels ) {

		$panels['bs_financial_pack'] = array(
			'id' => 'bs_financial_pack',
		);

		return $panels;
	}
}


add_filter( 'better-framework/panel/bs_financial_pack/config', 'bs_financial_panel_config', 10 );

if ( ! function_exists( 'bs_financial_panel_config' ) ) {
	/**
	 * Callback: Init's BF options
	 *
	 * @param $panel
	 *
	 * @return array
	 */
	function bs_financial_panel_config( $panel ) {

		$panel = array(
			'config'     => array(
				'parent'              => 'better-studio',
				'slug'                => 'better-studio/financial-pack',
				'name'                => __( 'Financial Pack', 'better-studio' ),
				'page_title'          => __( 'Financial Pack', 'better-studio' ),
				'menu_title'          => __( 'Financial Pack', 'better-studio' ),
				'capability'          => 'manage_options',
				'icon_url'            => NULL,
				'position'            => 80.04,
				'exclude_from_export' => FALSE,
			),
			'panel-name' => _x( 'Financial Pack Pro', 'Panel title', 'better-studio' ),
			'panel-desc' => '<p>' . __( 'Cryptocurrency, Currencies and Stock Market', 'better-studio' ) . '</p>',
		);

		return $panel;
	} // bs_financial_panel_config
}


add_filter( 'better-framework/panel/bs_financial_pack/std', 'bs_financial_panel_std', 10 );

if ( ! function_exists( 'bs_financial_panel_std' ) ) {
	/**
	 * Callback: Init's BF options
	 *
	 * Filter: better-framework/panel/options
	 *
	 * @param $fields
	 *
	 * @return array
	 */
	function bs_financial_panel_std( $fields ) {

		include BS_Financial_Pack_Pro::dir_path( 'includes/options/panel-std.php' );

		return $fields;
	}
}


add_filter( 'better-framework/panel/bs_financial_pack/fields', 'bs_financial_panel_fields', 10 );

if ( ! function_exists( 'bs_financial_panel_fields' ) ) {
	/**
	 * Callback: Init's BF options
	 *
	 * Filter: better-framework/panel/options
	 *
	 * @param $fields
	 *
	 * @return array
	 */
	function bs_financial_panel_fields( $fields ) {

		include BS_Financial_Pack_Pro::dir_path( 'includes/options/panel-fields.php' );

		return $fields;
	}
}
