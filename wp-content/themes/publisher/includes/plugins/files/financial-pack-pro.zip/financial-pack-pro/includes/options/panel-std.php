<?php

//
// Translation
//
$fields['convert_amount'] = array(
	'std' => 'Amount',
);
$fields['convert_from']   = array(
	'std' => 'From',
);
$fields['convert_to']     = array(
	'std' => 'To',
);
//
$fields['events_date']     = array(
	'std' => 'Date',
);
$fields['events_subject']  = array(
	'std' => 'Subject',
);
$fields['events_location'] = array(
	'std' => 'Location',
);
//
$fields['table_name']           = array(
	'std' => 'Name',
);
$fields['table_price']          = array(
	'std' => 'Price',
);
$fields['table_change']         = array(
	'std' => 'Change',
);
$fields['table_last_price']     = array(
	'std' => 'Last Price',
);
$fields['table_marketcap']      = array(
	'std' => 'Market Cap',
);
$fields['table_supply']         = array(
	'std' => 'Supply',
);
$fields['table_change7d']       = array(
	'std' => 'Change % (7D)',
);
$fields['table_change_percent'] = array(
	'std' => '% Change',
);
$fields['table_performance']    = array(
	'std' => 'Performance',
);
//
$fields['result'] = array(
	'std' => 'Result',
);

//
// Caching Options
//
$fields['cache_time'] = array(
	'std' => 2,
);
