<?php
/**
 * Type 15 => Style 0
 *
 * @var $atts
 * @var $api
 */

$data = $api->get( array(
	'logo'            => array(),
	'prices'          => array(),
	'changes_average' => array(),
) );

if ( empty( $data ) ) {

	bsfp_print_error();

	return;
}

foreach ( $data as $symbol => $item ) {

	$currency   = $item['main_currency'];
	$title_attr = $item['name'];
	$_check     = array(
		'currency'     => '',
		'stock-market' => '',
	);

	if ( isset( $_check[ $atts['data-type'] ] ) ) {
		$name   = $symbol;
		$symbol = $item['name'];
	} else {
		$name = $item['name'];
	}

	?>
	<div class='bs-fp bs-fp-22 bs-fp-t15 bs-fp-s0'>
		<div class="bs-fp-inner bsfp-clearfix">
			<?php if ( ! empty( $item['logo'] ) ) { ?>
				<div class="fp-logo">
					<img src="<?php echo $item['logo']; ?>">
				</div>
			<?php } ?>

			<div class="fp-text">
				<div class="fp-name" title="<?php echo $title_attr; ?>"><?php echo $name; ?> </div>
				<div class="fp-name fp-s-name" title="<?php echo $title_attr; ?>"><?php echo $symbol; ?></div>
				<?php if ( $arrow = bsfp_get_arrow_class( $item, $currency, 'style-2' ) ) {
					?>
					<span class="fp-arrow fp-<?php echo $item['changes_average'][ $currency ]['state']; ?> <?php echo $arrow; ?>"></span>
					<?php
				} ?>
			</div>

			<?php if ( isset( $item['prices'][ $currency ] ) ) { ?>
				<div class="fp-price"><?php echo bsfp_format_currency( $item['prices'][ $currency ], $currency ); ?></div>
			<?php } ?>
		</div>
	</div>
<?php }
