<?php
/**
 * Type 3 => Style 0
 *
 * @var $atts
 * @var $api
 */

$args = array(
	'prices'          => array(),
	'changes_average' => array(),
	'statistics'      => array(),
);

$items = $api->get( $args );

if ( empty( $items ) ) {

	bsfp_print_error();

	return;
}

$_check = array(
	'cryptocurrency' => array(
		'market-cap' => '',
		'supply'     => '',
	),
);

?>
<table class='bs-fpt bs-fpt-3 bs-fpt-t3' cellpadding="3">
	<thead>
	<tr>
		<td><?php bs_financial_pack_translation_echo( 'table_name' ); ?></td>
		<td><?php bs_financial_pack_translation_echo( 'table_price' ); ?></td>
		<td><?php bs_financial_pack_translation_echo( 'table_marketcap' ); ?></td>
		<td><?php bs_financial_pack_translation_echo( 'table_change7d' ); ?></td>
	</tr>
	</thead>
	<tbody>
	<?php foreach ( $items as $symbol => $item ) {

		$currency = $item['main_currency'];
		$chart_id = 'ct-chart-' . mt_rand();
		$state    = ! empty( $item['changes_average'][ $currency ]['state'] ) ? $item['changes_average'][ $currency ]['state'] : 'fixed';

		?>
		<tr>
			<td class="fpt-td-name">
				<span class="fpt-name"><?php echo $item['name']; ?></span>
			</td>

			<td class="fpt-td-price">
				<?php if ( isset( $item['prices'][ $currency ] ) ) { ?>
					<div class="fp-price"><?php echo bsfp_format_currency( $item['prices'][ $currency ], $currency ); ?></div>
				<?php } ?>
			</td>

			<td class="fpt-td-market-cap">
					<span class="fpt-market-cap"><?php echo bsfp_format_currency(
							$item['statistics'][ $currency ]['market_cap'],
							$currency
						); ?></span>
			</td>

			<td class="fpt-td-changes">
				<?php if ( ! empty( $item['changes_average'][ $currency ] ) ) { ?>
					<div class="fpt-changes">
						<?php echo bsfp_format_percentage(
							$item['changes_average'][ $currency ]['percentage'],
							2
						); ?>
					</div>
				<?php } ?>

			</td>
		</tr>
	<?php } ?>
	</tbody>
</table>