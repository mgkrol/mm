<?php
/**
 * Type 1 => Style 2
 *
 * @var $atts
 * @var $api
 */

$args = array(
	'prices'          => array(),
	'changes_average' => array(),
);

if ( $atts['data-type'] === 'currency' ) {
	$args['logo'] = array();
}

$data = $api->get( $args );

if ( empty( $data ) ) {

	bsfp_print_error();

	return;
}

foreach ( $data as $symbol => $item ) {

	$currency   = $item['main_currency'];
	$title_attr = $item['name'];

	?>
	<div class='bs-fp bs-fp-3 bs-fp-t1 bs-fp-s2'>
		<div class="bs-fp-inner">
			<?php if ( ! empty( $item['logo'] ) ) { ?>
				<div class="fp-logo">
					<img alt="<?php echo $title_attr; ?>" src="<?php echo $item['logo']; ?>">
				</div>
			<?php } ?>

			<div class="fp-name" title="<?php echo $title_attr; ?>"><?php echo $symbol; ?></div>

			<?php if ( isset( $item['prices'][ $currency ] ) ) { ?>
				<div class="fp-price">
					<?php echo bsfp_format_currency( $item['prices'][ $currency ], $currency, FALSE ); ?>
					<sub><?php echo $currency; ?></sub>
				</div>
			<?php } ?>

			<?php if ( $arrow = bsfp_get_arrow_class( $item, $currency, 'style-3' ) ) {
				?>
				<span class="fp-arrow fp-<?php echo $item['changes_average'][ $currency ]['state']; ?> <?php echo $arrow; ?>"></span>
				<?php
			} ?>
		</div>
	</div>
<?php } ?>
