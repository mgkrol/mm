<?php
/**
 * Type 2 => Style 1
 *
 * @var $atts
 * @var $api
 */

$args = array(
	'logo'            => array(),
	'prices'          => array(),
	'changes_average' => array(),
	'daily_history'   => array(),
	'statistics'      => array(),
);

$items = $api->get( $args );

if ( empty( $items ) ) {

	bsfp_print_error();

	return;
}

$_check = array(
	'cryptocurrency' => array(
		'market-cap' => '',
		'supply'     => '',
	),
);

?>

<table class='bs-fpt bs-fpt-2 bs-fpt-t2'>
	<thead>
	<tr>
		<td></td>
		<td><?php bs_financial_pack_translation_echo( 'table_name' ); ?></td>
		<td><?php bs_financial_pack_translation_echo( 'table_price' ); ?></td>
		<?php if ( isset( $_check[ $atts['data-type'] ]['market-cap'] ) ) { ?>
			<td><?php bs_financial_pack_translation_echo( 'table_marketcap' ); ?></td>
			<td><?php bs_financial_pack_translation_echo( 'table_supply' ); ?></td>
		<?php } ?>
		<td><?php bs_financial_pack_translation_echo( 'table_change7d' ); ?></td>
		<td><?php bs_financial_pack_translation_echo( 'table_performance' ); ?></td>
	</tr>
	</thead>

	<tbody>
	<?php

	$counter = 0;

	foreach ( $items as $symbol => $item ) {

		$counter  += 1;
		$currency = $item['main_currency'];
		$state    = ! empty( $item['changes_average'][ $currency ]['state'] ) ? $item['changes_average'][ $currency ]['state'] : 'fixed';

		?>
		<tr>
			<td class="fpt-td-number"><?php echo $counter; ?></td>
			<td class="fpt-td-name">
				<?php if ( ! empty( $item['logo'] ) ) { ?>
					<span class="fpt-logo">
						<img src="<?php echo $item['logo']; ?>">
					</span>
				<?php } ?>
				<span class="fpt-name"><?php echo $item['name']; ?></span>
			</td>

			<td class="fpt-td-price">
				<?php if ( isset( $item['prices'][ $currency ] ) ) { ?>
					<div class="fpt-price"><?php echo bsfp_format_currency( $item['prices'][ $currency ], $currency ); ?></div>
				<?php } ?>
			</td>

			<?php if ( isset( $_check[ $atts['data-type'] ]['market-cap'] ) ) { ?>

				<td class="fpt-td-market-cap">
					<?php if ( isset( $item['statistics'][ $currency ]['market_cap'] ) ) { ?>
						<span class="fpt-market-cap"><?php echo bsfp_format_currency(
								$item['statistics'][ $currency ]['market_cap'],
								$currency
							); ?></span>
					<?php } ?>
				</td>

				<td class="fpt-td-market-supply">
					<?php if ( isset( $item['statistics'][ $currency ]['supply'] ) ) { ?>
						<span class="fpt-market-cap"><?php echo $item['statistics'][ $currency ]['supply'], ' ', $symbol; ?></span>
					<?php } ?>
				</td>
			<?php } ?>

			<td class="fpt-td-changes">
				<?php if ( ! empty( $item['changes_average'][ $currency ] ) ) { ?>
					<div class="fpt-changes fpt-<?php echo $state; ?>">
						<?php echo bsfp_format_percentage(
							$item['changes_average'][ $currency ]['percentage'],
							2
						); ?>
					</div>
				<?php } ?>
			</td>

			<td class="fpt-td-chart">
				<div class="visualization">
					<div class="ct-chart bs-fpt-chart-list"
					     data-series="<?php echo implode( ',', $item['daily_history'][ $currency ] ) ?>"
					     data-width="100px"
					     data-height="26px"
					></div>
				</div>

				<div class="bs-fpt-gradient">
					<svg width="0" height="0">
						<defs>
							<linearGradient id="gradient-chart" x1="0%" y1="0%" x2="0%" y2="100%">
								<stop offset="60%" stop-color="#ddedf6"/>
								<stop offset="90%" stop-color="rgba(255, 255, 255, 0)"/>
							</linearGradient>
						</defs>
					</svg>
				</div>
			</td>
		</tr>
	<?php } ?>
	</tbody>
</table>
