<?php
/**
 * Type 16 => Style 0
 *
 * @var $atts
 * @var $api
 */

//
// Modify currencies for this style
//
{
	$currencies = array();

	if ( ! empty( $atts['currency'] ) ) {
		$currencies = explode( ',', $atts['currency'] );
	} else {
		$currencies = array( 'USD', 'EUR', 'GBP' );
	}

	$currencies = array_slice( $currencies + array( 'USD', 'EUR', 'GBP' ), 0, 3 );

	if ( $atts['data-type'] === 'currency' ) {
		$api->set_units( $currencies );
	} else {
		$api->set_currencies( $currencies );
	}
}

$data = $api->get( array(
	'prices'          => array(),
	'changes_average' => array(),
) );

if ( empty( $data ) ) {

	bsfp_print_error();

	return;
}

foreach ( $data as $symbol => $item ) {

	$currency   = $item['main_currency'];
	$title_attr = $item['name'];
	$_check     = array(
		'currency'     => '',
		'stock-market' => '',
	);

	if ( isset( $_check[ $atts['data-type'] ] ) ) {
		$name   = $symbol;
		$symbol = $item['name'];
	} else {
		$name = $item['name'];
	}

	?>
	<div class='bs-fp bs-fp-23 bs-fp-t16 bs-fp-s0'>
		<div class="bs-fp-inner">
			<div class="fp-text">
				<div class="fp-name" title="<?php echo $title_attr; ?>"><?php echo $name; ?></div>
				<?php if ( ! empty( $item['changes_average'][ $currency ] ) ) { ?>
					<div class="fp-changes fp-changes-percentage"><?php echo bsfp_format_percentage( $item['changes_average'][ $currency ]['percentage'] ); ?></div>
				<?php } ?>
			</div>

			<ul class="price-list">
				<?php foreach ( $currencies as $curr ) {

					if ( empty( $item['prices'][ $curr ] ) ) {
						continue;
					}

					?>
					<li class="fp-price"><?php echo $curr; ?>
						<span><?php echo bsfp_format_currency( $item['prices'][ $curr ], $curr, FALSE ); ?></span>
					</li>
				<?php } ?>
			</ul>
		</div>
	</div>
<?php }
