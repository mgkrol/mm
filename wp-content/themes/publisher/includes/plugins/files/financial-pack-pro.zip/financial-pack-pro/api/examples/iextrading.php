<?php

$abspath = realpath( str_repeat( '../', 5 ) );

require $abspath . '/wp-load.php';

/**
 * @var BS_Financial_Stock_Service $api
 */
$api = bsfp_api_instance( 'iextrading' );

if ( ! $api ) {
	die( "<h1>Error :-/  cannot connect to iextrading</h1>" );
}


$api->set_companies( array( 'aapl', 'fb', 'goog' ) );
$api->set_currencies( array( 'USD', 'IRR', 'GBP', 'EUR' ) );


$results = $api->get( array(
	//	'daily_history'   => array(), // arguments
	'hourly_history'  => array(),
	'changes_average' => array(),
	'statistics'      => array(),
	'logo'            => array(),
	'prices'          => array(),
) );

bf_var_dump_exit( $results );


try {

	//	bf_var_dump( $api->prices() );

	//	bf_var_dump( $api->logo_list() );

	//	bf_var_dump( $api->statistics() );

	//	bf_var_dump( $api->changes_average() );

	//	bf_var_dump( $api->hourly_history() );

	//	bf_var_dump( $api->daily_history() );


} catch( Exception $e ) {

	var_dump( $e->getMessage() );
	exit;
}



