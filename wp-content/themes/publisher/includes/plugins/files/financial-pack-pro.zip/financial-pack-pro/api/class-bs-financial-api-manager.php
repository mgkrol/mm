<?php


class BS_Financial_API_Manager {

	/**
	 * Store services class list
	 *
	 * @var array
	 */
	protected $providers_list = array(
		'crypto_compare' => 'BS_Financial_CryptoCompare_API',
		'iextrading'     => 'BS_Financial_IexTrading_API',
		'currencies'     => 'BS_Financial_Currencies_API',
	);


	/**
	 * Store service provider object
	 *
	 * @var BS_Financial_Service_Base
	 */
	protected $provider_instance;


	/**
	 * Store options array
	 *
	 * @var array
	 */
	protected $options = array();


	/**
	 * List of currencies code to fetch data from api
	 *
	 * @var array
	 */
	protected $currencies = array();


	/**
	 * BS_Financial_API_Manager constructor.
	 *
	 * @param array $currencies
	 * @param array $options
	 */
	public function __construct( $currencies = array(), $options = array() ) {

		$this->set_currencies( $currencies );

		$this->set_options( $options );


		if ( ! class_exists( 'BS_Financial_Service_Base' ) ) {

			/** @noinspection PhpIncludeInspection */
			require BS_Financial_Pack_Pro::dir_path( 'api/class-bs-financial-service-base.php' );
		}

		if ( ! class_exists( 'BS_Financial_Crypto_Service' ) ) {

			/** @noinspection PhpIncludeInspection */
			require BS_Financial_Pack_Pro::dir_path( 'api/class-bs-financial-crypto-service.php' );
		}

		if ( ! class_exists( 'BS_Financial_Stock_Service' ) ) {

			/** @noinspection PhpIncludeInspection */
			require BS_Financial_Pack_Pro::dir_path( 'api/class-bs-financial-stock-service.php' );
		}

		if ( ! class_exists( 'BS_Financial_Currency_Service' ) ) {

			/** @noinspection PhpIncludeInspection */
			require BS_Financial_Pack_Pro::dir_path( 'api/class-bs-financial-currency-service.php' );
		}

		if ( ! class_exists( 'BS_Financial_Pack_Pro_Utilities' ) ) {

			/** @noinspection PhpIncludeInspection */
			require BS_Financial_Pack_Pro::dir_path( 'includes/class-bs-financial-pack-pro-utilities.php' );
		}
	}


	/**
	 * Get fresh instance of manager class
	 *
	 * @param string $api
	 * @param array  $currencies
	 * @param array  $options
	 *
	 * @return self
	 */
	public static function instance( $api, $currencies = array(), $options = array() ) {

		$instance = new self( $currencies, $options );

		$instance->load_service_provider_object( $api );

		return $instance;
	}

	//
	// Helper methods
	//

	/**
	 * Automattic and set service provider object
	 *
	 * @param string $provider name of the service provider
	 *
	 * @return bool true on success or false on failure.
	 */
	public function load_service_provider_object( $provider ) {

		if ( ! isset( $this->providers_list[ $provider ] ) ) {
			return FALSE;
		}

		$class_name = $this->providers_list[ $provider ];
		$filename   = str_replace( '_', '-', $class_name );
		$filename   = sprintf( 'class-%s.php', strtolower( $filename ) );

		if ( ! class_exists( $class_name ) ) {

			$provider_class_path = dirname( __FILE__ ) . "/providers/$filename";

			if ( ! file_exists( $provider_class_path ) ) {
				return FALSE;
			}

			/** @noinspection PhpIncludeInspection */
			include $provider_class_path;
		}

		/**
		 * @var BS_Financial_Service_Base $api
		 */
		$api = new $class_name;

		$this->set_service( $api );

		return TRUE;
	}


	/**
	 * Autoload one available service provider
	 *
	 * @return bool
	 */
	protected function autoload_service_provider_object() {

		foreach ( $this->providers_list as $api => $_ ) {

			if ( $this->load_service_provider_object( $api ) ) {
				return TRUE;
			}
		}

		return FALSE;
	}



	//
	// Getter and Setters
	//


	public function set_currencies( array $currencies ) {

		$this->currencies = array_map( 'strtoupper', $currencies );
	}


	public function get_currencies() {

		return $this->currencies;
	}


	public function set_options( array $options ) {

		$this->options = $options;
	}


	public function get_options() {

		return $this->options;
	}


	/**
	 * Set custom service provider object
	 *
	 * @param BS_Financial_Service_Base $service
	 */
	public function set_service( BS_Financial_Service_Base $service ) {

		$this->provider_instance = $service;
	}


	/**
	 * Get service provider object
	 *
	 * @return BS_Financial_Service_Base
	 */
	public function get_service() {

		return $this->provider_instance;
	}

}
