<?php


if ( ! interface_exists( 'BS_Financial_Service_Interface' ) ) {

	require BS_Financial_Pack_Pro::dir_path( 'api/contracts/interface-bs-financial-service-adapter.php' );
}


class BC_Financial_API_Exporter implements BS_Financial_Service_Interface {

	/**
	 * @var BS_Financial_Service_Base
	 */
	protected $provider;


	/**
	 * @param BS_Financial_Service_Base $provider
	 */
	public function __construct( BS_Financial_Service_Base $provider = NULL ) {

		if ( $provider ) {

			$this->set_provider( $provider );
		}
	}

	/**
	 * Set service provider object
	 *
	 * @param BS_Financial_Service_Base $provider
	 */
	public function set_provider( BS_Financial_Service_Base $provider ) {

		$this->provider = $provider;
	}

	/**
	 * @return BS_Financial_Service_Base
	 */
	public function get_provider() {

		return $this->provider;
	}

	/**
	 * Access API Interface
	 *
	 * @param array $methods
	 *
	 * @return array
	 * @throws Exception
	 */
	public function get( array $methods ) {

		$results       = $this->provider->get( $methods );
		$base_currency = $this->provider->get_base_currency();
		$rates         = bsfp_get_exchange_rate( array_keys( bsfp_get_currencies_list_option() ), $base_currency );

		$currencies = array();

		/**
		 * $currencies_logo array format must compatible with financial-pack.js -> get_currency_logo() function
		 */
		$currencies_logo = array(
			'pattern' => array(),
			'list'    => array(),
		);

		$local_logo_url = BS_Financial_Pack_Pro::dir_url( '/img/coins/%code%.svg' );

		foreach ( $results as $symbol => $info ) {

			if ( isset( $info['prices'][ $base_currency ] ) ) {

				$currencies[ $symbol ] = $info['prices'][ $base_currency ];
			}

			$symbol_q   = preg_quote( str_replace( '*', '', strtolower( $symbol ) ), '#' );
			$cc_pattern = '#^(?: https?:)?// (?: w{3}.)? cryptocompare.com/media/(.*?)/' . $symbol_q . '.png$#x';

			if ( isset( $info['logo'] ) ) {

				if ( preg_match( $cc_pattern, $info['logo'], $match ) ) {

					$currencies_logo['pattern']['cc']['list'][ $symbol ] = $match[1];

				} elseif ( str_replace( '%code%', strtolower( $symbol ), $local_logo_url ) === $info['logo'] ) {

					$currencies_logo['pattern']['local']['list'][] = $symbol;

				} else {

					$currencies_logo['list'][ $symbol ] = $info['logo'];
				}
			}
		}

		if ( ! empty( $currencies_logo['pattern']['local'] ) ) {
			$currencies_logo['pattern']['local']['url'] = $local_logo_url;;
		}

		if ( ! empty( $currencies_logo['pattern']['cc'] ) ) {
			$currencies_logo['pattern']['cc']['url'] = 'https://www.cryptocompare.com/media/%id%/%code%.png';
		}

		$cash_logo_url = BS_Financial_Pack_Pro::dir_url( '/img/currencies/%code%.svg' );

		return compact( 'currencies', 'currencies_logo', 'rates', 'cash_logo_url', 'base_currency' );
	}
}