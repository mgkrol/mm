<?php
/**
 * Type 3 => Style 1
 *
 * @var $atts
 * @var $api
 */

$data = $api->get( array(
	'prices'          => array(),
	'changes_average' => array(),
	'logo'            => array(),
) );

if ( empty( $data ) ) {

	bsfp_print_error();

	return;
}

foreach ( $data as $symbol => $item ) {

	$currency   = $item['main_currency'];
	$title_attr = $symbol;
	$_check     = array(
		'currency'     => '',
		'stock-market' => '',
	);

	if ( isset( $_check[ $atts['data-type'] ] ) ) {
		$name       = $symbol;
		$title_attr = $item['name'];
	} else {
		$name = $item['name'];
	}

	?>
	<div class='bs-fp bs-fp-8 bs-fp-t3 bs-fp-s1'>
		<div class="bs-fp-inner">
			<?php if ( ! empty( $item['logo'] ) ) { ?>
				<div class="fp-logo">
					<img alt="<?php echo $title_attr; ?>" src="<?php echo $item['logo']; ?>">
				</div>
			<?php } ?>

			<div class="fp-name" title="<?php echo $title_attr; ?>"><?php echo $name; ?></div>

			<?php if ( $arrow = bsfp_get_arrow_class( $item, $currency, 'style-2' ) ) {
				?>
				<span class="fp-arrow fp-<?php echo $item['changes_average'][ $currency ]['state']; ?> <?php echo $arrow; ?>"></span>
				<?php
			} ?>

			<?php if ( isset( $item['prices'][ $currency ] ) ) { ?>
				<div class="fp-price fp-<?php echo $item['changes_average'][ $currency ]['state']; ?>"><?php echo bsfp_format_currency( $item['prices'][ $currency ], $currency ); ?></div>
			<?php } ?>

			<?php if ( ! empty( $item['changes_average'][ $currency ] ) ) { ?>
				<div class="fp-changes fp-changes-percentage fp-<?php echo $item['changes_average'][ $currency ]['state']; ?>">
					(<?php echo bsfp_format_percentage(
						$item['changes_average'][ $currency ]['percentage'],
						2
					); ?>)
				</div>
			<?php } ?>

		</div>
	</div>
<?php }
