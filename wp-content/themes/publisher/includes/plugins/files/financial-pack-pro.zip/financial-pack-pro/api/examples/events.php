<?php

$abspath = realpath( str_repeat( '../', 5 ) );

require $abspath . '/wp-load.php';

$events = bsfp_get_events( 'cryptovest' );
//$events = bsfp_get_events( 'bitcoin' );

if ( $events === FALSE ) {
	die( "<h1>Cannot fetch events :-/</h1>" );
}

?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport"
	      content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Events</title>
</head>
<body>


<table border="1">
	<thead>
	<tr>
		<th>Title</th>
		<th>Date</th>
		<th>location</th>
		<th>Description</th>
	</tr>
	</thead>
	<tbody>

	<?php foreach ( $events as $event ) : ?>

		<tr>
			<td><a href="<?php echo $event['url'] ?>" target="_blank"><?php echo $event['title'] ?></a></td>
			<td><?php echo $event['date'] ?></td>
			<td><?php echo $event['location'] ?></td>
			<td><?php echo $event['desc'] ?></td>
		</tr>


	<?php endforeach; ?>

	</tbody>
</table>

</body>
</html>