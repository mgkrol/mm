<?php


class BS_Financial_CryptoCompare_API extends BS_Financial_Crypto_Service {

	/**
	 * @var string
	 */
	public $base_url = 'https://min-api.cryptocompare.com';


	/**
	 * Internal param usage
	 *
	 * @var int
	 */
	protected $_limit = 0;

	/**
	 * Internal param usage
	 *
	 * @var int
	 */
	protected $_to_timestamp = 0;


	/**
	 * Response Queue
	 *
	 * @var array
	 */
	protected $queue = array();

	/**
	 * Local logo list
	 *
	 * @var array
	 */
	protected $local_logo = array(
		'ICON',
		'ADA',
		'AE',
		'AION',
		'ARDR',
		'ARK',
		'BAT',
		'BCH',
		'BCN',
		'BNB',
		'BNT',
		'BTC',
		'BTG',
		'BTMSTAR',
		'BTS',
		'CNX',
		'DASH',
		'DCN',
		'DCR',
		'DENT',
		'DGB',
		'DGD',
		'DOGE',
		'DRGN',
		'ELF',
		'EMC',
		'ENG',
		'EOS',
		'ETC',
		'ETH',
		'ETHOS',
		'ETN',
		'FCT',
		'FUN',
		'GBYTE',
		'GNT',
		'GXS',
		'HSR',
		'ICN',
		'IOST',
		'KCN',
		'KCS',
		'KIN',
		'KMD',
		'LINK',
		'LRC',
		'LSK',
		'LTC',
		'MAID',
		'MIOTA',
		'MKR',
		'MONA',
		'MTL',
		'NANO',
		'NAS',
		'NEBL',
		'NEO',
		'NULS',
		'NXT',
		'OMG',
		'PART',
		'PAY',
		'PIVX',
		'POWR',
		'PPT',
		'QASH',
		'QTUM',
		'R',
		'RDD',
		'REP',
		'REQ',
		'RHOC',
		'SALT',
		'SC',
		'SNT',
		'STEEM',
		'STORJ',
		'STORM',
		'STRAT',
		'SYS',
		'TRX',
		'USDT',
		'VEN',
		'VERI',
		'VTC',
		'WAVES',
		'WTC',
		'XEM',
		'XLM',
		'XMR',
		'XRP',
		'XVG',
		'XZC',
		'ZEC',
		'ZIL',
		'ZRX',
	);


	/**
	 * Get api url
	 *
	 * @param string $endpoint
	 *
	 * @return string
	 */
	public function url( $endpoint ) {

		return trailingslashit( $this->base_url ) . ltrim( $endpoint, '/' );
	}


	/**
	 * Is api ready to use
	 *
	 * @return bool
	 */
	public function ready() {

		return bsfp_is_host_accessible( $this->base_url );
	}


	/**
	 * Slice items to bypass server size limitation
	 *
	 * @return array
	 */
	protected function slice_items() {

		$max   = 300; // server max items size ( as string ) = 300
		$group = 0;
		$chars = $loop = 0;

		$list = array();

		foreach ( $this->config['items'] as $coin ) {

			$chars += strlen( $coin );

			if ( $chars + $loop >= $max ) {

				$loop = $chars = 0;
				$group ++;

			} else {

				$list[ $group ][] = $coin;
			}

			$loop ++;
		}

		return $list;
	}


	/**
	 * Fetch list of currencies price
	 *
	 * @return bool
	 * @throws Exception
	 */
	protected function fetch_prices() {

		$result = array();

		foreach ( $this->slice_items() as $items ) {

			/** @noinspection SpellCheckingInspection */
			$url = sprintf(
				'%s?fsyms=%s&tsyms=%s',
				$this->url( 'data/pricemulti' ),
				implode( ',', $items ),
				$this->base_currency
			);

			$response = BS_Financial_Pack_Pro_Utilities::request( $url );

			if ( ! $response || ! is_array( $response ) ) {

				return FALSE;
			}

			foreach ( $response as $key => $value ) {

				$result[ $key ] = $this->format_value( array_shift( $value ) );
			}
		}

		$this->queue['prices'] = $result;

		return TRUE;
	}


	/**
	 * Get amount of changes in last 24 hour
	 *
	 * @return bool
	 */
	protected function fetch_changes_average() {

		$currencies = array_combine( $this->config['items'], $this->config['items'] );
		$changes    = array_map( array( $this, 'fetch_changes_average_single' ), $currencies );

		if ( $changes = array_filter( $changes ) ) {

			$this->queue['changes_average'] = $changes;

			return TRUE;
		}

		return FALSE;
	}


	/**
	 * Fetch currency changes amount
	 *
	 * @param string $currency
	 *
	 * @throws Exception
	 * @access internal
	 *
	 * @return array|bool
	 */
	protected function fetch_changes_average_single( $currency ) {

		/** @noinspection SpellCheckingInspection */
		$url = sprintf(
			'%s?fsym=%s&tsym=%s&e=CCCAGG', // fixme: check markets list
			$this->url( 'data/generateAvg' ),
			$currency,
			$this->base_currency
		);

		if ( ! $request = BS_Financial_Pack_Pro_Utilities::request( $url ) ) {
			return $this->changes_average_fallback( $currency );
		}

		/** @noinspection SpellCheckingInspection */
		if ( ! isset( $request['RAW']['CHANGEPCT24HOUR'] ) ) {
			return $this->changes_average_fallback( $currency );
		}

		return $this->format_changes(
			$request['RAW']['CHANGE24HOUR'],
			$request['RAW']['CHANGEPCT24HOUR']
		);
	}

	/**
	 * Calculate currency changes average by historical daily data
	 *
	 * @param string $currency
	 *
	 * @return array|bool
	 * @throws Exception
	 */
	public function changes_average_fallback( $currency ) {

		if ( empty( $this->queue['daily_history'] ) ) {

			if ( ! $this->fetch_daily_history() ) {
				return FALSE;
			}
		}

		if ( empty( $this->queue['daily_history'][ $currency ][ $this->base_currency ] ) ) {

			return FALSE;
		}

		$d = $this->queue['daily_history'][ $currency ][ $this->base_currency ];

		$today_price     = array_pop( $d );
		$yesterday_price = array_pop( $d );

		$changed_value      = $today_price - $yesterday_price;
		$changed_percentage = $changed_value * 100 / $yesterday_price;

		return $this->format_changes(
			$changed_value,
			$changed_percentage
		);
	}

	/**
	 * Get list of currencies logo
	 *
	 * @return bool
	 */
	protected function fetch_logo() {

		/** @noinspection SpellCheckingInspection */
		$url = $this->url( 'data/all/coinlist' );

		if ( ! $all_currencies = BS_Financial_Pack_Pro_Utilities::request( $url ) ) {
			return FALSE;
		}

		if ( empty( $all_currencies['Data'] ) ) {
			return FALSE;
		}

		$logo_list  = array();
		$image_base = $all_currencies['BaseImageUrl'];
		//
		$local_logo_url = BS_Financial_Pack_Pro::dir_url( '/img/coins/%code%.svg' );

		foreach ( $this->config['items'] as $symbol ) {

			if ( ! isset( $all_currencies['Data'][ $symbol ]['ImageUrl'] ) ) {
				continue;
			}

			if ( in_array( $symbol, $this->local_logo ) ) {

				$logo_list[ $symbol ] = str_replace( '%code%', strtolower( $symbol ), $local_logo_url );

			} else {

				$logo_list[ $symbol ] = trailingslashit( $image_base ) .
				                        ltrim( $all_currencies['Data'][ $symbol ]['ImageUrl'], '/' );
			}
		}

		if ( ! empty( $logo_list ) ) {

			$this->queue['logo'] = $logo_list;

			return TRUE;
		}

		return FALSE;
	}


	/**
	 * ‌Get statistics data
	 *
	 * 1. MarketCap
	 * 2. Supply
	 *
	 *
	 * @return array|bool false on failure
	 */
	protected function fetch_statistics() {

		$statistics = array();

		foreach ( $this->slice_items() as $items ) {

			/** @noinspection SpellCheckingInspection */
			$url = sprintf(
				'%s?fsyms=%s&tsyms=%s',
				$this->url( 'data/pricemultifull' ),
				implode( ',', $this->config['items'] ),
				$this->base_currency
			);

			if ( ! $result = BS_Financial_Pack_Pro_Utilities::request( $url ) ) {

				return FALSE;
			}

			if ( ! isset( $result['RAW'] ) || ! is_array( $result['RAW'] ) ) {

				return FALSE;
			}

			$stats = array_map( array( $this, 'prepare_currency_statistics' ), $result['RAW'] );

			if ( $stats = array_filter( $stats ) ) {

				$statistics = array_merge( $statistics, $stats );
			}
		}

		$this->queue['statistics'] = $statistics;

		return TRUE;
	}


	/**
	 * Prepare single currency statistics data
	 *
	 * @param array $items
	 *
	 * @access internal
	 * @return array|bool false on failure
	 */
	protected function prepare_currency_statistics( $items ) {

		$results = array();

		$info = array_shift( $items );

		return $this->format_statistics( array(
			'market_cap' => $info['MKTCAP'],
			'supply'     => $info['SUPPLY'],
		) );
	}


	/**
	 * History of price changes in given timestamp range
	 *
	 * @return bool
	 */
	protected function fetch_daily_history() {

		$this->_limit = 30;

		$currencies = array_combine( $this->config['items'], $this->config['items'] );
		$history    = array_map( array( $this, 'fetch_daily_history_single' ), $currencies );

		if ( $history = array_filter( $history ) ) {

			$this->queue['daily_history'] = $history;

			return TRUE;
		}

		return FALSE;
	}


	/**
	 * Fetch currency changes amount
	 *
	 * @param string $currency
	 *
	 * @access internal
	 * @return array|bool
	 */
	protected function fetch_daily_history_single( $currency ) {

		/** @noinspection SpellCheckingInspection */
		$url = sprintf(
			'%s?fsym=%s&tsym=%s&limit=%d&toTs=%d&aggregate=0', // fixme: check markets list
			$this->url( 'data/histoday' ),
			$currency,
			$this->base_currency,
			$this->_limit,
			time()
		);

		if ( ! $request = BS_Financial_Pack_Pro_Utilities::request( $url ) ) {
			return FALSE;
		}

		if ( empty( $request['Data'] ) ) {
			return FALSE;
		}

		if ( $data = $this->prepare_history_data( $request['Data'] ) ) {

			return $this->format_value_list( $data );
		}

		return FALSE;
	}


	/**
	 * @param array $data
	 *
	 * @access internal
	 * @return array|bool false on failure
	 */

	protected function prepare_history_data( $data ) {

		$result = array();

		if ( empty( $data ) || ! is_array( $data ) ) {
			return $result;
		}

		foreach ( $data as $d ) {

			if ( ! isset( $d['time'] ) || ! isset( $d['close'] ) ) {
				continue;
			}

			$result[ $d['time'] ] = $d['close'];
		}

		if ( ! empty( $result ) ) {

			return $result;
		}

		return FALSE;
	}


	/**
	 * History of price changes in given timestamp range
	 *
	 * @return bool
	 */
	protected function fetch_hourly_history() {

		$this->_limit = 24;  // server max limit is 2000

		$currencies = array_combine( $this->config['items'], $this->config['items'] );
		$history    = array_map( array( $this, 'fetch_hourly_history_single' ), $currencies );

		if ( $history = array_filter( $history ) ) {

			$this->queue['hourly_history'] = $history;

			return TRUE;
		}

		return FALSE;
	}


	/**
	 * Fetch currency changes amount
	 *
	 * @param string $currency
	 *
	 * @access internal
	 * @return array|bool false on failure.
	 */
	protected function fetch_hourly_history_single( $currency ) {

		/** @noinspection SpellCheckingInspection */
		$url = sprintf(
			'%s?fsym=%s&tsym=%s&limit=%d&toTs=%d&aggregate=0', // fixme: check markets list
			$this->url( 'data/histohour' ),
			$currency,
			$this->base_currency,
			$this->_limit,
			time()
		);


		if ( ! $request = BS_Financial_Pack_Pro_Utilities::request( $url ) ) {
			return FALSE;
		}

		if ( empty( $request['Data'] ) ) {
			return FALSE;
		}

		if ( $data = $this->prepare_history_data( $request['Data'] ) ) {

			return $this->format_value_list( $data );
		}

		return FALSE;
	}


	/**
	 * Get list of available item
	 *
	 * @return bool
	 */
	function fetch_items_list() {

		/** @noinspection SpellCheckingInspection */
		$url = $this->url( 'data/all/coinlist' );

		if ( ! $all_currencies = BS_Financial_Pack_Pro_Utilities::request( $url ) ) {
			return FALSE;
		}

		if ( empty( $all_currencies['Data'] ) || ! is_array( $all_currencies['Data'] ) ) {
			return FALSE;
		}

		$items          = array();
		$image_base_url = $all_currencies['BaseImageUrl'];
		//
		$local_logo_url = BS_Financial_Pack_Pro::dir_url( '/img/coins/%code%.svg' );

		foreach ( $all_currencies['Data'] as $symbol => $info ) {

			$items[ $symbol ] = array(
				'name'        => $info['CoinName'],
				'symbol'      => $info['Symbol'],
				'algorithm'   => $info['Algorithm'],
				'is_trending' => ! empty( $info['IsTrading'] ),
			);

			if ( in_array( $symbol, $this->local_logo ) ) {

				$items[ $symbol ]['logo'] = str_replace( '%code%', strtolower( $symbol ), $local_logo_url );

			} elseif ( ! empty( $info['ImageUrl'] ) ) {

				$items[ $symbol ]['logo'] = $image_base_url . $info['ImageUrl'];
			}
		}

		if ( ! empty( $items ) ) {

			$this->queue['items_list'] = $items;

			return TRUE;
		}

		return FALSE;
	}


	/**
	 * Request Results
	 *
	 * @return array
	 */
	protected function get_results() {

		return $this->queue;
	}
}