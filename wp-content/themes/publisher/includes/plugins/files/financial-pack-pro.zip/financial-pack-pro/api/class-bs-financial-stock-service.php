<?php


abstract class BS_Financial_Stock_Service extends BS_Financial_Service_Base {


	public function set_companies( $companies ) {

		$this->set_items( $companies );
	}

	//
	// Exchange methods
	//

	/**
	 * Convert amount of digital currencies list cash
	 *
	 * @param array $digital_list
	 *
	 * @return array|bool false on failure.
	 */
	public function exchange_to_cash( array $digital_list ) {

		$digital_list = array_map( 'strtoupper', $digital_list );

		if ( ! $prices = $this->prices() ) {
			return FALSE;
		}

		$converted = array();

		foreach ( $digital_list as $currency => $value ) {

			if ( ! isset( $prices[ $currency ] ) ) {
				continue;
			}

			$converted[ $currency ] = $this->_exchange_to_cash_single( $prices[ $currency ], $value );
		}

		return $converted;
	}


	/**
	 * @param array $currencies
	 * @param int   $base_value
	 *
	 * @access internal
	 * @return array
	 */
	protected function _exchange_to_cash_single( array $currencies, $base_value ) {

		$results = array();

		foreach ( $currencies as $currency => $c_value ) {

			$results[ $currency ] = $base_value * $c_value;
		}

		return $results;
	}


	/**
	 * Convert amount of digital currencies list cash
	 *
	 * @param array $cash_list
	 *
	 * @return array
	 */
	public function exchange_to_digital( array $cash_list ) {

		$cash_list = array_map( 'strtoupper', $cash_list );

		if ( ! $prices = $this->prices() ) {
			return FALSE;
		}

		$converted = array();

		foreach ( $cash_list as $cash => $cash_value ) {

			foreach ( $prices as $d_currency => $d_values ) {

				if ( ! isset( $d_values[ $cash ] ) ) {
					continue;
				}

				$converted[ $d_currency ][ $cash ] = $cash_value / $d_values[ $cash ];
			}
		}

		return $converted;
	}
}
