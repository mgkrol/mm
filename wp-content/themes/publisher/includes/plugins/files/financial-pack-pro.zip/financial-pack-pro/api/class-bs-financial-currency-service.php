<?php


abstract class BS_Financial_Currency_Service extends BS_Financial_Service_Base {

	protected $_base_currency;


	public function set_units( $units ) {

		$this->set_items( $units );


		$this->base_currency  = array_shift( $units );
		$this->_base_currency = $this->base_currency;
	}


	public function set_currencies( $currencies ) {

		parent::set_currencies( $currencies );

		$this->base_currency = $this->_base_currency;
	}


	/**
	 * @param float $value
	 *
	 * @throws Exception
	 * @return array
	 */
	protected function format_value( $value ) {

		try {

			$rates = bsfp_get_exchange_rate( $this->get_items(), $this->base_currency );

		} catch( Exception $e ) {

			return array();
		}

		$results = array();

		foreach ( $rates as $currency => $rate ) {

			$results[ $currency ] = $rate / $value;
		}

		return $results;
	}


	/**
	 * @param float $changed_value
	 * @param float $changed_percentage
	 *
	 * @return array
	 * @throws Exception
	 */
	protected function format_changes( $changed_value, $changed_percentage ) {

		$rates   = bsfp_get_exchange_rate( $this->get_items(), $this->base_currency );
		$results = array();

		if ( $changed_value === 0.0 || $changed_value === 0 ) {

			$state = 'fixed';

		} else {

			$state = $changed_value > 0 ? 'up' : 'down';
		}

		foreach ( $rates as $currency => $rate ) {

			$results[ $currency ]['percentage'] = $changed_percentage;
			$results[ $currency ]['value']      = $changed_value / $rate;
			$results[ $currency ]['state']      = $state;
		}

		return $results;
	}


	/**
	 * @param array $values
	 *
	 * @return array
	 * @throws Exception
	 */
	protected function format_history( $values ) {

		if ( ! is_array( $values ) ) {

			return $values;
		}

		$rates   = bsfp_get_exchange_rate( $this->get_items(), $this->base_currency );
		$results = array();

		foreach ( $values as $currency => $historical_data ) {

			foreach ( $historical_data as $key => $value ) {

				foreach ( $rates as $unit_currency => $rate ) {

					$results[ $currency ][ $unit_currency ][ $key ] = $value / $rate;
				}
			}
		}

		return $results;
	}

}
