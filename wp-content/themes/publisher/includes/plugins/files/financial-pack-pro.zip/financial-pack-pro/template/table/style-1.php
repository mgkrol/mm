<?php
/**
 * Type 1 => Style 1
 *
 * @var $atts
 * @var $api
 */

$args = array(
	'logo'            => array(),
	'prices'          => array(),
	'changes_average' => array(),
	'daily_history'   => array(),
	'statistics'      => array(),
);

$items = $api->get( $args );

if ( empty( $items ) ) {

	bsfp_print_error();

	return;
}

$_check = array(
	'cryptocurrency' => array(
		'market-cap' => '',
		'supply'     => '',
	),
);

?>
<table class='bs-fpt bs-fpt-1 bs-fpt-t1'>
	<thead>
	<tr>
		<td><?php bs_financial_pack_translation_echo( 'table_name' ); ?></td>
		<td><?php bs_financial_pack_translation_echo( 'table_price' ); ?></td>
		<?php if ( isset( $_check[ $atts['data-type'] ]['market-cap'] ) ) { ?>
			<td><?php bs_financial_pack_translation_echo( 'table_marketcap' ); ?></td>
			<td><?php bs_financial_pack_translation_echo( 'table_supply' ); ?></td>
		<?php } ?>
		<td><?php bs_financial_pack_translation_echo( 'table_change7d' ); ?></td>
		<td><?php bs_financial_pack_translation_echo( 'table_performance' ); ?></td>
	</tr>
	</thead>
	<tbody>

	<?php foreach ( $items as $symbol => $item ) {

		$currency = $item['main_currency'];
		$state    = ! empty( $item['changes_average'][ $currency ]['state'] ) ? $item['changes_average'][ $currency ]['state'] : 'fixed';

		?>
		<tr>
			<td class="fpt-td-name">
				<?php if ( ! empty( $item['logo'] ) ) { ?>
					<span class="fpt-logo">
						<img src="<?php echo $item['logo']; ?>">
					</span>
				<?php } ?>

				<span class="fpt-name"><?php echo $item['name']; ?></span>
				<span class="fpt-s-name"><?php echo $symbol; ?></span>
			</td>

			<td class="fpt-td-price">
				<?php if ( isset( $item['prices'][ $currency ] ) ) { ?>
					<div class="fp-price"><?php echo bsfp_format_currency( $item['prices'][ $currency ], $currency ); ?></div>
				<?php } ?>
			</td>

			<?php if ( isset( $_check[ $atts['data-type'] ]['market-cap'] ) ) { ?>

				<td class="fpt-td-market-cap">
					<?php if ( isset( $item['statistics'][ $currency ]['market_cap'] ) ) { ?>
						<span class="fpt-market-cap"><?php echo bsfp_format_currency(
								$item['statistics'][ $currency ]['market_cap'],
								$currency
							); ?></span>
					<?php } ?>
				</td>

				<td class="fpt-td-supply">
					<?php if ( isset( $item['statistics'][ $currency ]['supply'] ) ) { ?>
						<span class="fpt-market-cap"><?php echo $item['statistics'][ $currency ]['supply'], ' ', $symbol; ?></span>
					<?php } ?>
				</td>

			<?php } ?>

			<td class="fpt-td-changes">
				<div class="fpt-change-price fpt-<?php echo $state; ?>">
					<?php if ( $arrow = bsfp_get_arrow_class( $item, $currency, 'style-3' ) ) {
						?>
						<span class="fpt-arrow <?php echo $arrow; ?>"></span>
						<?php
					} ?>

					<?php if ( ! empty( $item['changes_average'][ $currency ] ) ) { ?>
						<div class="fpt-changes">
							<?php echo bsfp_format_percentage(
								$item['changes_average'][ $currency ]['percentage'],
								2
							); ?>
						</div>
					<?php } ?>
				</div>
			</td>

			<td class="fpt-td-chart">
				<div class="visualization">
					<div class="ct-chart bs-fpt-chart-list fpt-<?php echo $state; ?>"
					     data-series="<?php echo implode( ',', $item['daily_history'][ $currency ] ) ?>"
					     data-width="100px"
					     data-height="26px"
					></div>
				</div>
			</td>
		</tr>
	<?php } ?>
	</tbody>
</table>
