<?php


/**
 * BS FP Stock Market Table Shortcode
 */
class BSFP_StockMarket_Table_Shortcode extends BF_Shortcode {

	function __construct( $id, $options ) {

		$id = 'bsfp-stockmarket-table';

		$_options = array(
			'defaults'       => array(
				'scheme'           => 'light',
				'style'            => 'style-1',
				//
				'stocks'           => 'top-x-stocks',
				'stocks-count'     => 10,
				'stocks-selected'  => '',
				'currency'         => 'USD',
				//
				'title'            => __( 'Stock Market Table', 'better-studio' ),
				'show_title'       => 1,
				'icon'             => '',
				'heading_style'    => 'default',
				'heading_color'    => '',
				//
				'bs-show-desktop'  => 1,
				'bs-show-tablet'   => 1,
				'bs-show-phone'    => 1,
				'css'              => '',
				'custom-css-class' => '',
				'custom-id'        => '',
			),
			'have_widget'    => TRUE,
			'have_vc_add_on' => TRUE,
		);

		if ( isset( $options['shortcode_class'] ) ) {
			$_options['shortcode_class'] = $options['shortcode_class'];
		}

		if ( isset( $options['widget_class'] ) ) {
			$_options['widget_class'] = $options['widget_class'];
		}

		parent::__construct( $id, $_options );
	}


	/**
	 * Filter custom css codes for shortcode widget!
	 *
	 * @param $fields
	 *
	 * @return array
	 */
	function register_custom_css( $fields ) {

		return $fields;
	}


	/**
	 * Handle displaying of shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function display( array $atts, $content = '' ) {

		$atts['data-type'] = 'stock-market';

		if ( ! empty( $content ) ) {
			$atts['content'] = $content;
		}

		if ( empty( $atts['css-class'] ) ) {
			$atts['css-class'] = '';
		}

		//
		// Setup API for cryptocurrency
		//
		{
			$api = bsfp_api_instance( 'iextrading' );

			if ( ! $api ) {
				// todo print error "Currency can not fire!"
			}

			// validate stocks value
			{
				$_check = array(
					'top-x-stocks' => '',
					'selected'     => '',
				);

				if ( empty( $atts['stocks'] ) || ! isset( $_check[ $atts['stocks'] ] ) ) {
					$atts['stocks'] = 'top-x-stocks';
				}
			}

			if ( $atts['stocks'] == 'top-x-stocks' ) {

				if ( empty( $atts['stocks-count'] ) ) {
					$atts['stocks-count'] = 10;
				}

				$stocks = array_keys( bsfp_get_stock_market_top_gainers_list( $atts['stocks-count'] ) );
			} else {

				if ( empty( $atts['stocks-selected'] ) ) {
					$stocks = array_keys( bsfp_get_stock_market_top_gainers_list( 10 ) );
				} else {
					$stocks = explode( ',', $atts['stocks-selected'] );
				}
			}

			$api->set_items( $stocks );
			$api->set_currencies( ! empty( $atts['currency'] ) ? explode( ',', $atts['currency'] ) : array( 'USD' ) );
		}

		ob_start();

		BS_Financial_Pack_Pro()->enqueue_queue['chartist'] = TRUE;

		?>
		<div class="better-studio-shortcode bsfp-clearfix bsfp-scheme-<?php echo $atts['scheme']; ?> <?php echo $atts['css-class']; ?> <?php echo $atts['custom-css-class']; ?>"
			<?php echo ! empty( $atts['custom-id'] ) ? "id='{$atts['custom-id']}'" : ''; ?>
		>
			<?php

			bf_shortcode_show_title( $atts ); // show title

			// Custom and Auto Generated CSS Codes
			if ( ! empty( $atts['css-code'] ) ) {
				bf_add_css( $atts['css-code'], TRUE, TRUE );
			}

			?>
			<div class='fpt-wrapper-body fpt-style-<?php echo $atts['style']; ?>'>
				<?php

				bsfp_load_view(
					"table/{$atts['style']}",
					compact( 'atts', 'api' ),
					array(
						'echo' => TRUE
					)
				);

				?>
			</div>
		</div>
		<?php

		return ob_get_clean();
	}


	/**
	 * Fields of VC
	 *
	 * @return array
	 */
	public function get_fields() {

		$fields = array(
			array(
				'type' => 'tab',
				'name' => __( 'Style', 'better-studio' ),
				'id'   => 'style_tab',
			),
			array(
				'name'             => __( 'Style', 'better-studio' ),
				'id'               => 'style',
				'type'             => 'select_popup',
				'deferred-options' => array(
					'callback' => 'bsfp_stockmarket_table_styles_option',
				),
				'texts'            => array(
					'modal_title'   => __( 'Choose Style', 'better-studio' ),
					'box_pre_title' => __( 'Active style', 'better-studio' ),
					'box_button'    => __( 'Change Style', 'better-studio' ),
				),
				'section_class'    => 'bsfp-style-field',
				//
				'vc_admin_label'   => TRUE,
			),
			array(
				'name'           => __( 'Color Scheme', 'better-studio' ),
				'id'             => 'scheme',
				'type'           => 'select',
				'options'        => array(
					'light' => __( 'Light (White Skin)', 'better-studio' ),
					'dark'  => __( 'Dark (Black Skin)', 'better-studio' ),
				),
				//
				'vc_admin_label' => FALSE,
			),
			array(
				'type' => 'tab',
				'name' => __( 'Stock Market & Currency', 'better-studio' ),
				'id'   => 'stocks',
			),
			array(
				'name'           => __( 'Stock Market Type', 'better-studio' ),
				'id'             => 'stocks',
				'type'           => 'select',
				'options'        => array(
					'top-x-stocks' => __( 'Top X Popular Stock Markets', 'better-studio' ),
					'selected'     => __( 'Manually Selected Stock Markets', 'better-studio' ),
				),
				//
				'vc_admin_label' => FALSE,
			),
			array(
				'name'           => __( 'Stock Markets Count', 'better-studio' ),
				'id'             => 'stocks-count',
				'type'           => 'text',
				'show_on'        => array(
					array(
						'stocks=top-x-stocks',
					)
				),
				//
				'vc_admin_label' => FALSE,
			),
			array(
				'name'           => __( 'Select Stock Market', 'better-studio' ),
				'id'             => 'stocks-selected',
				'type'           => 'ajax_select',
				'get_name'       => 'bsfp_stock_market_select_callback_name',
				'callback'       => 'bsfp_stock_market_select_callback',
				'show_on'        => array(
					array(
						'stocks=selected',
					)
				),
				//
				'vc_admin_label' => FALSE,
			),
			array(
				'name'             => __( 'Currency', 'better-studio' ),
				'id'               => 'currency',
				'type'             => 'select',
				'deferred-options' => array(
					'callback' => 'bsfp_get_currencies_list_option',
				),
				//
				'vc_admin_label'   => TRUE,
			),
		);


		/**
		 * Retrieve heading fields from outside (our themes are defining them)
		 */
		{
			$heading_fields = apply_filters( 'better-framework/shortcodes/heading-fields', array(), $this->id );

			if ( $heading_fields ) {
				$fields = array_merge( $heading_fields, $fields );
			}
		}


		/**
		 * Retrieve design fields from outside (our themes are defining them)
		 */
		{
			$design_fields = apply_filters( 'better-framework/shortcodes/design-fields', array(), $this->id );

			if ( $design_fields ) {
				$fields = array_merge( $fields, $design_fields );
			}
		}

		return $fields;
	}


	/**
	 * Registers Visual Composer Add-on
	 */
	function register_vc_add_on() {

		vc_map( array(
			'name'           => __( 'Stock Markets Table', 'better-studio' ),
			"base"           => $this->id,
			"weight"         => 10,
			"wrapper_height" => 'full',

			"category" => __( 'Financial Pack', 'better-studio' ),
			"params"   => $this->vc_map_listing_all(),
		) );

	} // register_vc_add_on

}


/**
 * BS FP Stock Market Table Widget
 */
class BSFP_StockMarket_Table_Widget extends BF_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {

		parent::__construct(
			'bsfp-stockmarket-table',
			__( 'FP - Stock Market Table', 'better-studio' ),
			array(
				'description' => __( 'Stock Market table', 'better-studio' )
			)
		);
	} // __construct


	/**
	 * Loads fields
	 */
	function load_fields() {

		// Back end form fields
		$this->fields = array(
			array(
				'name' => __( 'Title', 'better-studio' ),
				'id'   => 'title',
				'type' => 'text',
			),
			// Style Options
			array(
				'type'  => 'group',
				'name'  => __( 'Style', 'better-studio' ),
				'id'    => 'style_tab',
				'state' => 'close',
			),
			array(
				'name'             => __( 'Style', 'better-studio' ),
				'id'               => 'style',
				'type'             => 'select_popup',
				'deferred-options' => array(
					'callback' => 'bsfp_stockmarket_table_styles_option',
				),
				'texts'            => array(
					'modal_title'   => __( 'Choose Style', 'better-studio' ),
					'box_pre_title' => __( 'Active style', 'better-studio' ),
					'box_button'    => __( 'Change Style', 'better-studio' ),
				),
				'section_class'    => 'bsfp-style-field',
			),
			array(
				'name'    => __( 'Color Scheme', 'better-studio' ),
				'id'      => 'scheme',
				'type'    => 'select',
				'options' => array(
					'light' => __( 'Light (White Skin)', 'better-studio' ),
					'dark'  => __( 'Dark (Black Skin)', 'better-studio' ),
				),
			),
			//
			array(
				'type'  => 'group',
				'name'  => __( 'Stock Markets & Currency', 'better-studio' ),
				'id'    => 'stocks',
				'state' => 'close',
			),
			array(
				'name'    => __( 'Stock Markets Type', 'better-studio' ),
				'id'      => 'stocks',
				'type'    => 'select',
				'options' => array(
					'top-x-stocks' => __( 'Top X Popular Stock Markets', 'better-studio' ),
					'selected'     => __( 'Manually Selected Stock Markets', 'better-studio' ),
				),
			),
			array(
				'name'    => __( 'Stock Markets Count', 'better-studio' ),
				'id'      => 'stocks-count',
				'type'    => 'text',
				'show_on' => array(
					array(
						'stocks=top-x-stocks',
					)
				),
			),
			array(
				'name'     => __( 'Select Stock Market', 'better-studio' ),
				'id'       => 'stocks-selected',
				'type'     => 'ajax_select',
				'get_name' => 'bsfp_stock_market_select_callback_name',
				'callback' => 'bsfp_stock_market_select_callback',
				'show_on'  => array(
					array(
						'stocks=selected',
					)
				),
			),
			array(
				'name'             => __( 'Currency', 'better-studio' ),
				'id'               => 'currency',
				'type'             => 'select',
				'deferred-options' => array(
					'callback' => 'bsfp_get_currencies_list_option',
				),
			),
		);
	} // load_fields
}
