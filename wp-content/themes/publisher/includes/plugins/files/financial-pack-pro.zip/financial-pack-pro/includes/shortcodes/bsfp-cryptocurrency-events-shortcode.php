<?php


/**
 * BS FP Cryptocurrency Events Shortcode
 */
class BSFP_Cryptocurrency_Events_Shortcode extends BF_Shortcode {

	function __construct( $id, $options ) {

		$id = 'bsfp-cryptocurrency-events';

		$_options = array(
			'defaults'       => array(
				'scheme'           => 'light',
				'style'            => 'style-1',
				'data-source'      => 'bitcoin',
				'events-count'     => '',
				//
				'title'            => __( 'Cryptocurrency Events', 'better-studio' ),
				'show_title'       => 1,
				'icon'             => '',
				'heading_style'    => 'default',
				'heading_color'    => '',
				//
				'bs-show-desktop'  => 1,
				'bs-show-tablet'   => 1,
				'bs-show-phone'    => 1,
				'css'              => '',
				'custom-css-class' => '',
				'custom-id'        => '',
			),
			'have_widget'    => TRUE,
			'have_vc_add_on' => TRUE,
		);

		if ( isset( $options['shortcode_class'] ) ) {
			$_options['shortcode_class'] = $options['shortcode_class'];
		}

		if ( isset( $options['widget_class'] ) ) {
			$_options['widget_class'] = $options['widget_class'];
		}

		parent::__construct( $id, $_options );
	}


	/**
	 * Filter custom css codes for shortcode widget!
	 *
	 * @param $fields
	 *
	 * @return array
	 */
	function register_custom_css( $fields ) {

		return $fields;
	}


	/**
	 * Handle displaying of shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function display( array $atts, $content = '' ) {

		$atts['data-type'] = 'cryptocurrency';

		if ( ! empty( $content ) ) {
			$atts['content'] = $content;
		}

		if ( empty( $atts['css-class'] ) ) {
			$atts['css-class'] = '';
		}

		ob_start();

		//
		// Validate data source
		//
		{
			$_check = array(
				'cryptovest' => '',
				'bitcoin'    => '',
			);

			if ( ! isset( $_check[ $atts['data-source'] ] ) ) {
				$atts['data-source'] = 'cryptovest';
			}
		}

		//
		// Fetch data
		//
		{
			$events = bsfp_get_events( $atts['data-source'] );

			if ( ! empty( $atts['events-count'] ) ) {
				$events = array_slice( $events, 0, $atts['events-count'] );
			}
		}

		?>
		<div class="bsfp-events bsfp-events-cryptocurrency better-studio-shortcode bsfp-clearfix bsfp-scheme-<?php echo $atts['scheme']; ?> <?php echo $atts['css-class']; ?> <?php echo $atts['custom-css-class']; ?>"
			<?php echo ! empty( $atts['custom-id'] ) ? "id='{$atts['custom-id']}'" : ''; ?>
		>
			<?php

			bf_shortcode_show_title( $atts ); // show title

			// Custom and Auto Generated CSS Codes
			if ( ! empty( $atts['css-code'] ) ) {
				bf_add_css( $atts['css-code'], TRUE, TRUE );
			}

			bsfp_load_view(
				"events/{$atts['style']}",
				compact( 'atts', 'events' ),
				array(
					'echo' => TRUE,
				)
			);

			?>
		</div>
		<?php

		return ob_get_clean();
	}


	/**
	 * Fields of VC
	 *
	 * @return array
	 */
	public function get_fields() {

		$fields = array(
			array(
				'type' => 'tab',
				'name' => __( 'Style', 'better-studio' ),
				'id'   => 'style_tab',
			),
			array(
				'name'             => __( 'Style', 'better-studio' ),
				'id'               => 'style',
				'type'             => 'select_popup',
				'deferred-options' => array(
					'callback' => 'bsfp_cryptocurrency_events_styles_option',
				),
				'texts'            => array(
					'modal_title'   => __( 'Choose Style', 'better-studio' ),
					'box_pre_title' => __( 'Active style', 'better-studio' ),
					'box_button'    => __( 'Change Style', 'better-studio' ),
				),
				'section_class'    => 'bsfp-style-field',
				'column_class'     => 'three-column',
				//
				'vc_admin_label'   => TRUE,
			),
			array(
				'name'           => __( 'Color Scheme', 'better-studio' ),
				'id'             => 'scheme',
				'type'           => 'select',
				'options'        => array(
					'light' => __( 'Light (White Skin)', 'better-studio' ),
					'dark'  => __( 'Dark (Black Skin)', 'better-studio' ),
				),
				//
				'vc_admin_label' => FALSE,
			),
			array(
				'type' => 'tab',
				'name' => __( 'Events', 'better-studio' ),
				'id'   => 'style_tab',
			),
			array(
				'name'           => __( 'Events Data Source', 'better-studio' ),
				'id'             => 'data-source',
				'type'           => 'select',
				'options'        => array(
					'bitcoin'    => __( 'Bitcoin.org', 'better-studio' ),
					'cryptovest' => __( 'Cryptovest.com', 'better-studio' ),
				),
				//
				'vc_admin_label' => TRUE,
			),
			array(
				'name' => __( 'Events Count', 'better-studio' ),
				'id'   => 'events-count',
				'desc' => __( 'Max events count in the table.', 'better-studio' ),
				'type' => 'text',
			),
		);


		/**
		 * Retrieve heading fields from outside (our themes are defining them)
		 */
		{
			$heading_fields = apply_filters( 'better-framework/shortcodes/heading-fields', array(), $this->id );

			if ( $heading_fields ) {
				$fields = array_merge( $heading_fields, $fields );
			}
		}


		/**
		 * Retrieve design fields from outside (our themes are defining them)
		 */
		{
			$design_fields = apply_filters( 'better-framework/shortcodes/design-fields', array(), $this->id );

			if ( $design_fields ) {
				$fields = array_merge( $fields, $design_fields );
			}
		}

		return $fields;
	}


	/**
	 * Registers Visual Composer Add-on
	 */
	function register_vc_add_on() {

		vc_map( array(
			'name'           => __( 'Cryptocurrency Events', 'better-studio' ),
			"base"           => $this->id,
			"weight"         => 10,
			"wrapper_height" => 'full',

			"params" => $this->vc_map_listing_all(),
		) );

	} // register_vc_add_on

}


/**
 * BS FP Cryptocurrency Events Widget
 */
class BSFP_Cryptocurrency_Events_Widget extends BF_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {

		parent::__construct(
			'bsfp-cryptocurrency-events',
			__( 'FP - Cryptocurrency Events', 'better-studio' ),
			array(
				'description' => __( 'Cryptocurrency Events', 'better-studio' )
			)
		);
	} // __construct


	/**
	 * Loads fields
	 */
	function load_fields() {

		// Back end form fields
		$this->fields = array(
			array(
				'name' => __( 'Title', 'better-studio' ),
				'id'   => 'title',
				'type' => 'text',
			),
			array(
				'type'  => 'group',
				'name'  => __( 'Style', 'better-studio' ),
				'id'    => 'style_tab',
				'state' => 'close',
			),
			array(
				'name'             => __( 'Style', 'better-studio' ),
				'id'               => 'style',
				'type'             => 'select_popup',
				'deferred-options' => array(
					'callback' => 'bsfp_cryptocurrency_events_styles_option',
				),
				'texts'            => array(
					'modal_title'   => __( 'Choose Style', 'better-studio' ),
					'box_pre_title' => __( 'Active style', 'better-studio' ),
					'box_button'    => __( 'Change Style', 'better-studio' ),
				),
				'section_class'    => 'bsfp-style-field',
				'column_class'     => 'three-column',
			),
			array(
				'name'    => __( 'Color Scheme', 'better-studio' ),
				'id'      => 'scheme',
				'type'    => 'select',
				'options' => array(
					'light' => __( 'Light (White Skin)', 'better-studio' ),
					'dark'  => __( 'Dark (Black Skin)', 'better-studio' ),
				),
			),
			array(
				'type'  => 'group',
				'name'  => __( 'Events', 'better-studio' ),
				'id'    => 'style_tab',
				'state' => 'close',
			),
			array(
				'name'    => __( 'Events Data Source', 'better-studio' ),
				'id'      => 'data-source',
				'type'    => 'select',
				'options' => array(
					'bitcoin'    => __( 'Bitcoin.org', 'better-studio' ),
					'cryptovest' => __( 'Cryptovest.com', 'better-studio' ),
				),
			),
			array(
				'name' => __( 'Events Count', 'better-studio' ),
				'id'   => 'events-count',
				'desc' => __( 'Max events count in the table.', 'better-studio' ),
				'type' => 'text',
			),
		);
	} // load_fields
}
