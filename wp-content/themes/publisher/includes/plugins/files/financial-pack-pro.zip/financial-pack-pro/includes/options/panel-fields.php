<?php
//
//$fields[] = array(
//	'name' => __( 'General', 'better-studio' ),
//	'id'   => 'general_settings',
//	'type' => 'tab',
//	'icon' => 'bsai-global',
//);


//
// Translation
//
$fields[] = array(
	'name' => __( 'Translation', 'better-studio' ),
	'id'   => 'translation_settings',
	'type' => 'tab',
	'icon' => 'bsai-global',
);


$fields[]                 = array(
	'name'  => __( 'Converter Widget', 'better-studio' ),
	'desc'  => '',
	'type'  => 'group',
	'state' => 'open',
);
$fields['convert_amount'] = array(
	'name'            => __( 'Amount', 'better-studio' ),
	'id'              => 'convert_amount',
	'std'             => 'Amount',
	'type'            => 'text',
	'container_class' => 'highlight-hover',
);
$fields['convert_from']   = array(
	'name'            => __( 'From', 'better-studio' ),
	'id'              => 'convert_from',
	'std'             => 'From',
	'type'            => 'text',
	'container_class' => 'highlight-hover',
);
$fields['convert_to']     = array(
	'name'            => __( 'To', 'better-studio' ),
	'id'              => 'convert_to',
	'std'             => 'To',
	'type'            => 'text',
	'container_class' => 'highlight-hover',
);

$fields[]                  = array(
	'name'  => __( 'Cryptocurrency Event Table', 'better-studio' ),
	'desc'  => '',
	'type'  => 'group',
	'state' => 'open',
);
$fields['events_date']     = array(
	'name'            => __( 'Date', 'better-studio' ),
	'id'              => 'events_date',
	'type'            => 'text',
	'container_class' => 'highlight-hover',
);
$fields['events_subject']  = array(
	'name'            => __( 'Subject', 'better-studio' ),
	'id'              => 'events_subject',
	'type'            => 'text',
	'container_class' => 'highlight-hover',
);
$fields['events_location'] = array(
	'name'            => __( 'Location', 'better-studio' ),
	'id'              => 'events_location',
	'type'            => 'text',
	'container_class' => 'highlight-hover',
);

$fields[]                       = array(
	'name'  => __( 'Tables', 'better-studio' ),
	'desc'  => '',
	'type'  => 'group',
	'state' => 'open',
);
$fields['table_name']           = array(
	'name'            => __( 'Name', 'better-studio' ),
	'id'              => 'table_name',
	'type'            => 'text',
	'container_class' => 'highlight-hover',
);
$fields['table_price']          = array(
	'name'            => __( 'Price', 'better-studio' ),
	'id'              => 'table_price',
	'type'            => 'text',
	'container_class' => 'highlight-hover',
);
$fields['table_last_price']     = array(
	'name'            => __( 'Last Price', 'better-studio' ),
	'id'              => 'table_last_price',
	'type'            => 'text',
	'container_class' => 'highlight-hover',
);
$fields['table_marketcap']      = array(
	'name'            => __( 'Market Cap', 'better-studio' ),
	'id'              => 'table_marketcap',
	'type'            => 'text',
	'container_class' => 'highlight-hover',
);
$fields['table_supply']         = array(
	'name'            => __( 'Supply', 'better-studio' ),
	'id'              => 'table_supply',
	'type'            => 'text',
	'container_class' => 'highlight-hover',
);
$fields['table_change']         = array(
	'name'            => __( 'Change', 'better-studio' ),
	'id'              => 'table_change',
	'type'            => 'text',
	'container_class' => 'highlight-hover',
);
$fields['table_change7d']       = array(
	'name'            => __( 'Change % (7D)', 'better-studio' ),
	'id'              => 'table_change7d',
	'type'            => 'text',
	'container_class' => 'highlight-hover',
);
$fields['table_change_percent'] = array(
	'name'            => __( '% Change', 'better-studio' ),
	'id'              => 'table_change_percent',
	'type'            => 'text',
	'container_class' => 'highlight-hover',
);
$fields['table_performance']    = array(
	'name'            => __( 'Performance', 'better-studio' ),
	'id'              => 'table_performance',
	'type'            => 'text',
	'container_class' => 'highlight-hover',
);
$fields[]                       = array(
	'name'  => __( 'Converters', 'better-studio' ),
	'desc'  => '',
	'type'  => 'group',
	'state' => 'open',
);
$fields['result']               = array(
	'name'            => __( 'Result', 'better-studio' ),
	'id'              => 'result',
	'type'            => 'text',
	'container_class' => 'highlight-hover',
);


//
// Caching Options
//
$fields[]             = array(
	'name' => __( 'Caching Options', 'better-studio' ),
	'id'   => 'cache_options_title',
	'type' => 'tab',
	'icon' => 'bsai-database',
);
$fields['cache_time'] = array(
	'name'    => __( 'Maximum Lifetime of Cache', 'better-studio' ),
	'id'      => 'cache_time',
	'type'    => 'select',
	'options' => array(
		1  => __( '1 hours', 'better-studio' ),
		2  => __( '2 hours', 'better-studio' ),
		3  => __( '3 hours', 'better-studio' ),
		4  => __( '4 hours', 'better-studio' ),
		5  => __( '5 hours', 'better-studio' ),
		6  => __( '6 hours', 'better-studio' ),
		7  => __( '7 hours', 'better-studio' ),
		8  => __( '8 hours', 'better-studio' ),
		9  => __( '9 hours', 'better-studio' ),
		10 => __( '10 hours', 'better-studio' ),
		11 => __( '11 hours', 'better-studio' ),
		12 => __( '12 hours', 'better-studio' ),
		13 => __( '13 hours', 'better-studio' ),
		14 => __( '14 hours', 'better-studio' ),
		15 => __( '15 hours', 'better-studio' ),
		16 => __( '16 hours', 'better-studio' ),
		17 => __( '17 hours', 'better-studio' ),
		18 => __( '18 hours', 'better-studio' ),
		19 => __( '19 hours', 'better-studio' ),
		20 => __( '20 hours', 'better-studio' ),
		21 => __( '21 hours', 'better-studio' ),
		22 => __( '22 hours', 'better-studio' ),
		23 => __( '23 hours', 'better-studio' ),
		24 => __( '24 hours', 'better-studio' ),

	)
);
$fields[]             = array(
	'name'        => __( 'Clear Data Base Saved Caches', 'better-studio' ),
	'id'          => 'cache_clear_all',
	'type'        => 'ajax_action',
	'button-name' => '<i class="fa fa-refresh"></i> ' . __( 'Clear All Caches', 'better-studio' ),
	'callback'    => 'BS_Financial_Pack_Pro::clear_cache_all',
	'confirm'     => __( 'Are you sure for deleting all caches?', 'better-studio' ),
	'desc'        => __( 'This allows you to clear all caches that are saved in data base.', 'better-studio' )
);
