<?php
/**
 * Type 1 => Style 4
 *
 * @var $atts
 */
?>
<div class='bs-fpc bs-fpc-4 bs-fpc-t1 bs-fpc-s3'>
	<form class="fpc-form">

		<div class="fpc-input-section fpc-input-section-from bsfp-clearfix">
			<label class="fpc-label-input"><?php bs_financial_pack_translation_echo( 'convert_amount' ) ?></label>
			<div class="fpc-field">
				<input type="text" class="fpc-input fpc-convert-from" value="1">
			</div>
		</div>

		<div class="fpc-input-section fpc-input-section-to bsfp-clearfix">
			<label class="fpc-label-input"><?php bs_financial_pack_translation_echo( 'convert_from' ) ?></label>
			<div class="fpc-field fpc-field-uni">
				<div class="fpc-select-field">
					<img class="fpc-crypto-icon fpc-from-currency-icon" src="<?php echo $atts['from_currency_logo'] ?>">
					<?php
					bsfp_dropdown_helper( $atts['from_currencies'], array(
						'attrs'    => array(
							'class' => 'fpc-input fpc-from-unit',
						),
						'selected' => $atts['from_currency']
					) )
					?>
					<span class="fpc-select-arrow bsfi-arrow2-s"></span>
				</div>
			</div>
		</div>

		<div class="fpc-input-section fpc-input-section-to bsfp-clearfix">
			<label class="fpc-label-input"><?php bs_financial_pack_translation_echo( 'convert_to' ) ?></label>
			<div class="fpc-field fpc-field-uni fpc-to-currency-field">
				<div class="fpc-select-field">
					<img class="fpc-flag-icon fpc-to-currency-icon" src="<?php echo $atts['to_currency_logo'] ?>">
					<?php
					bsfp_dropdown_helper( $atts['to_currencies'], array(
						'attrs'    => array(
							'class' => 'fpc-input fpc-to-unit',
						),
						'selected' => $atts['to_currency']
					) )
					?>
					<span class="fpc-select-arrow bsfi-arrow2-s"></span>
				</div>
			</div>
		</div>
		<div class="fpc-input-section">
			<label class="fpc-label-input"><?php bs_financial_pack_translation_echo( 'result' ) ?></label>
			<div class="fpc-result">
				<span class="fpc-from-currency-label">
					<span class="value">1</span> <span
							class="unit bsf-currency-code"><?php echo $atts['from_currency'] ?></span> =
				</span>
				<span class="fpc-to-currency-label">
					<span class="value"></span> <span
							class="unit bsf-currency-code"><?php echo $atts['to_currency'] ?></span>
				</span>
			</div>
		</div>
	</form>
</div>
