<?php


/**
 * @method array|bool logo_list() Get list of currencies logo
 * @method array|bool prices() Fetch list of currencies price
 * @method array|bool items_list() Get list of available item
 * @method array|bool changes_average() Get amount of changes in last 24 hour
 * @method array|bool statistics() ‌Get statistics data such as marketCap & supply
 * @method array|bool daily_history( $from, $to ) Daily history of price changes in given timestamp range
 * @method array|bool hourly_history( $from, $to ) Hourly history of price changes in given timestamp range
 */
abstract class BS_Financial_Service_Base {

	/**
	 * Store configuration array
	 *
	 * @var array
	 */
	protected $config = array();

	/**
	 * Is api ready to use
	 *
	 * @var bool
	 */
	protected $is_ready;


	/**
	 * Base currency
	 *
	 * @var string
	 */
	protected $base_currency = 'USD';


	//
	// Abstract API Methods
	//

	/**
	 * Is api ready to use
	 *
	 * @return bool true on it is and false if it's not
	 */
	abstract protected function ready();


	/**
	 * Fetch list of items price
	 *
	 * @return bool true on success or false failure.
	 */
	abstract protected function fetch_prices();


	/**
	 * Get amount of changes in last 24 hour
	 *
	 * @return bool true on success or false failure.
	 */
	abstract protected function fetch_changes_average();


	/**
	 * Get list of items logo
	 *
	 * @return bool true on success or false failure.
	 */
	abstract protected function fetch_logo();


	/**
	 * Daily history of price changes in given timestamp range
	 *
	 * @return bool true on success or false failure.
	 */
	abstract protected function fetch_daily_history();


	/**
	 * Hourly history of price changes in given timestamp range
	 *
	 * @return bool true on success or false failure.
	 */
	abstract protected function fetch_hourly_history();


	/**
	 * ‌Get item statistics data
	 *
	 * @return bool true on success or false failure.
	 */
	abstract protected function fetch_statistics();


	/**
	 * Get list of available items
	 *
	 * @return bool true on success or false failure.
	 */
	abstract protected function fetch_items_list();


	/**
	 * Request Results
	 *
	 * @return array|bool false on failure.
	 */
	abstract protected function get_results();


	/**
	 * Get item name
	 *
	 * @param string $id
	 *
	 * @return string
	 */
	abstract protected function get_name( $id );


	/**
	 * Access API Interface
	 *
	 * @param array $methods
	 *
	 * @return array
	 */
	public function get( array $methods ) {

		$cache_key = $this->cache_key( $methods );
		$cache     = $this->get_cache( $cache_key );

		if ( is_array( $cache ) ) {

			return $cache;
		}

		if ( ! $this->is_ready() ) {

			$backup = $this->get_backup( $cache_key, array() );

			$this->set_cache( $cache_key, $backup, BS_Financial_Pack_Pro()->get_cache_time() / 2 );

			return $backup;
		}

		foreach ( $methods as $method => $args ) {

			$callback = array( $this, "fetch_$method" );

			if ( is_callable( $callback ) ) {

				call_user_func_array( $callback, $args );
			}
		}

		if ( $result = $this->get_results() ) {

			$result = $this->prepare_results( $result );

			$this->set_cache( $cache_key, $result );
			$this->set_backup( $cache_key, $result );

			return $result;

		} else {

			$backup = $this->get_backup( $cache_key, array() );

			$this->set_cache( $cache_key, $backup, BS_Financial_Pack_Pro()->get_cache_time() / 2 );

			return $backup;
		}
	}


	/**
	 * @param array $data
	 *
	 * @return array
	 */
	protected function prepare_results( $data ) {

		$formatted = array();

		foreach ( $data as $method => $data ) {

			if ( ! is_array( $data ) ) {
				continue;
			}

			foreach ( $data as $currency => $things ) {

				if ( ! isset( $formatted[ $currency ] ) ) {

					$formatted[ $currency ]['name']          = $this->get_name( $currency );
					$formatted[ $currency ]['id']            = $currency;
					$formatted[ $currency ]['main_currency'] = $this->base_currency;
				}

				$formatted[ $currency ][ $method ] = $things;
			}
		}

		return $formatted;
	}


	/**
	 * Cache fetched response
	 *
	 * @access internal usage
	 *
	 * @param array $fetched_response
	 * @param array $methods
	 */
	protected function cache_response( array $fetched_response, $methods ) {

		foreach ( $fetched_response as $method => $response ) {

			if ( ! isset( $methods[ $method ] ) ) {
				continue;
			}

			$cache_key = $this->cache_key( $method, $methods[ $method ] );

			$this->set_cache( $cache_key, $response );
		}

	}

	//
	// Helper Methods
	//


	/**
	 * @param array $items list of items to fetch
	 * @param array $config
	 */
	public function init( array $items, $config = array() ) {

		if ( isset( $config['base_currencies'] ) ) {

			$this->set_currencies( $config['base_currencies'] );
		}

		if ( isset( $items ) ) {

			$this->set_items( $items );
		}
	}


	/**
	 * Is api ready to use
	 *
	 * @return bool
	 */
	public function is_ready() {

		if ( isset( $this->is_ready ) ) {
			return $this->is_ready;
		}

		return $this->is_ready = $this->ready();
	}


	//
	// Utility Methods
	//

	/**
	 * Get saved cache
	 *
	 * @param string $cache_key
	 *
	 * @return mixed
	 */
	public function get_cache( $cache_key ) {

		return get_transient( 'fp_data_' . $cache_key );
	}


	/**
	 * Save a data to cache
	 *
	 * @param string $cache_key
	 * @param mixed  $data
	 * @param int    $cache_time
	 *
	 * @return bool true if value set
	 */
	public function set_cache( $cache_key, $data, $cache_time = 0 ) {

		if ( ! $cache_time ) {
			$cache_time = BS_Financial_Pack_Pro()->get_cache_time();
		}

		return set_transient( 'fp_data_' . $cache_key, $data, $cache_time );
	}


	/**
	 * Get saved backup
	 *
	 * @param string $cache_key
	 * @param mixed  $default
	 *
	 * @return mixed
	 */
	public function get_backup( $cache_key, $default = FALSE ) {

		return get_option( 'fp_data_' . $cache_key, $default );
	}


	/**
	 * Save a data to cache
	 *
	 * @param string $cache_key
	 * @param mixed  $data
	 *
	 * @return bool true if value set
	 */
	public function set_backup( $cache_key, $data ) {

		return update_option( 'fp_data_' . $cache_key, $data, BS_Financial_Pack_Pro()->get_cache_time() );
	}


	/**
	 * Api Unique ID
	 *
	 * @return string
	 */
	public function id() {

		return get_class( $this );
	}


	/**
	 * @param array $currencies
	 */
	public function set_currencies( $currencies ) {

		$currencies = array_map( 'strtoupper', $currencies );
		$currencies = array_filter( array_unique( $currencies ) );

		$this->base_currency = $currencies[0];

		$this->config['base_currencies'] = $currencies;
	}


	/**
	 * @return null|array
	 */
	public function get_currencies() {

		if ( isset( $this->config['base_currencies'] ) ) {
			return $this->config['base_currencies'];
		}
	}


	/**
	 * @param array $items
	 */
	public function set_items( $items ) {

		$items = array_map( 'strtoupper', $items );
		$items = array_filter( array_unique( $items ) );

		$this->config['items'] = $items;
	}


	/**
	 * @return null|array
	 */
	public function get_items() {

		if ( isset( $this->config['items'] ) ) {
			return $this->config['items'];
		}
	}


	/**
	 * Get current active configuration
	 *
	 * @return array
	 */
	public function get_config() {

		return $this->config;
	}


	/**
	 * @param array $methods
	 *
	 * @return string
	 */
	protected function cache_key( $methods ) {

		$hash = md5( serialize( array_merge( $methods, $this->get_currencies(), $this->get_items() ) ) . get_class( $this ) );

		$hash = substr( $hash, 7, 22 );

		return "bsfp_cache_$hash";
	}


	/**
	 * @param array $values
	 * @param array $exclude
	 *
	 * @return array
	 * @throws Exception
	 */
	protected function format_value_list( $values, $exclude = array() ) {

		if ( ! is_array( $values ) ) {

			return $values;
		}

		$rates   = bsfp_get_exchange_rate( $this->config['base_currencies'], $this->base_currency );
		$results = array();

		foreach ( $rates as $currency => $rate ) {

			foreach ( $values as $key => $value ) {

				if ( is_numeric( $value ) && ! in_array( $key, $exclude ) ) {

					$results[ $currency ][ $key ] = $value * $rate;

				} else {

					$results[ $currency ][ $key ] = $value;
				}
			}
		}

		return $results;
	}


	/**
	 * @param float $value
	 *
	 * @throws Exception
	 * @return array
	 */
	protected function format_value( $value ) {

		try {

			$rates = bsfp_get_exchange_rate( $this->config['base_currencies'], $this->base_currency );

		} catch( Exception $e ) {

			return array();
		}

		$results = array();

		foreach ( $rates as $currency => $rate ) {

			$results[ $currency ] = $value * $rate;
		}

		return $results;
	}


	/**
	 * @param float $changed_value
	 * @param float $changed_percentage
	 *
	 * @return array
	 * @throws Exception
	 */
	protected function format_changes( $changed_value, $changed_percentage ) {

		$rates   = bsfp_get_exchange_rate( $this->get_currencies(), $this->base_currency );
		$results = array();

		foreach ( $rates as $currency => $rate ) {

			$results[ $currency ]['percentage'] = $changed_percentage;
			$results[ $currency ]['value']      = $changed_value * $rate;
			$results[ $currency ]['state']      = $changed_percentage > 0 ? 'up' : 'down';
		}

		return $results;
	}


	/**
	 * Get base currency code
	 */
	public function get_base_currency() {

		return $this->base_currency;
	}


	/**
	 * Set base currency code
	 *
	 * @param string $base_currency
	 */
	public function set_base_currency( $base_currency ) {

		$this->base_currency = $base_currency;
	}
}
