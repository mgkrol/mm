<?php


/**
 * BS FP Stock Market Shortcode
 */
class BSFP_StockMarket_Shortcode extends BF_Shortcode {

	function __construct( $id, $options ) {

		$id = 'bsfp-stockmarket';

		$_options = array(
			'defaults'       => array(
				'scheme'               => 'light',
				'style'                => 'widget-1',
				'align'                => 'auto',
				'columns'              => 2,
				'marquee-speed'        => 40,
				'marquee-pauseonhover' => TRUE,
				//
				'stocks'               => 'top-x-stocks',
				'stocks-count'         => 10,
				'stocks-selected'      => '',
				'currency'             => 'USD',
				//
				'title'                => __( 'Stock Market Widget', 'better-studio' ),
				'show_title'           => 1,
				'icon'                 => '',
				'heading_style'        => 'default',
				'heading_color'        => '',
				//
				'bs-show-desktop'      => 1,
				'bs-show-tablet'       => 1,
				'bs-show-phone'        => 1,
				'css'                  => '',
				'custom-css-class'     => '',
				'custom-id'            => '',
			),
			'have_widget'    => TRUE,
			'have_vc_add_on' => TRUE,
		);

		if ( isset( $options['shortcode_class'] ) ) {
			$_options['shortcode_class'] = $options['shortcode_class'];
		}

		if ( isset( $options['widget_class'] ) ) {
			$_options['widget_class'] = $options['widget_class'];
		}

		parent::__construct( $id, $_options );
	}


	/**
	 * Filter custom css codes for shortcode widget!
	 *
	 * @param $fields
	 *
	 * @return array
	 */
	function register_custom_css( $fields ) {

		return $fields;
	}


	/**
	 * Handle displaying of shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function display( array $atts, $content = '' ) {

		$atts['data-type'] = 'stock-market';

		if ( ! empty( $content ) ) {
			$atts['content'] = $content;
		}

		if ( empty( $atts['css-class'] ) ) {
			$atts['css-class'] = '';
		}

		//
		// Setup API for Stock Market
		//
		{
			$atts['stocks-count'] = 25;

			$api = bsfp_api_instance( 'iextrading' );

			// validate coins value
			{
				$_check = array(
					'top-x-stocks' => '',
					'selected'     => '',
				);

				if ( empty( $atts['stocks'] ) || ! isset( $_check[ $atts['stocks'] ] ) ) {
					$atts['stocks'] = 'top-x-stocks';
				}
			}

			if ( $atts['stocks'] == 'top-x-stocks' ) {

				if ( empty( $atts['stocks-count'] ) ) {
					$atts['stocks-count'] = 10;
				}

				$coins = array_keys( bsfp_get_stock_market_top_gainers_list( $atts['stocks-count'] ) );
			} else {

				if ( empty( $atts['stocks-selected'] ) ) {
					$coins = array_keys( bsfp_get_stock_market_top_gainers_list( 10 ) );
				} else {
					$coins = explode( ',', $atts['stocks-selected'] );
				}
			}

			$api->set_items( $coins );
			$api->set_currencies( ! empty( $atts['currency'] ) ? explode( ',', $atts['currency'] ) : array( 'USD' ) );
		}

		ob_start();

		//
		// Main tag attributes
		//
		{
			$attr_string = '';
			$attrs       = array(
				'class' => array(
					'bsfp-widgets-list',
					"bsfp-{$atts['style']}",
					"bsfp-align-{$atts['align']}"
				),
			);
		}

		//
		// Marquee attrs
		//
		if ( $atts['align'] === 'marquee' ) {
			if ( is_rtl() ) {
				$attrs['data-direction'] = 'right';
			} else {
				$attrs['data-direction'] = 'left';
			}

			if ( isset( $atts['marquee-speed'] ) && ! empty( $atts['marquee-speed'] ) ) {
				$attrs['data-speed'] = $atts['marquee-speed'];
			} else {
				$attrs['data-speed'] = 40;
			}

			if ( isset( $atts['marquee-pauseonhover'] ) ) {
				$attrs['data-pauseOnHover'] = $atts['marquee-pauseonhover'] ? 1 : 0;
			} else {
				$attrs['data-pauseOnHover'] = 1;
			}
		}

		if ( $atts['align'] == 'columned' ) {
			$attrs['class'][] = "bsfp-columns-{$atts['columns']}";
		}

		?>
		<div class="bsfp-widget bsfp-widget-stock-market better-studio-shortcode bsfp-scheme-<?php echo $atts['scheme']; ?> bsfp-clearfix <?php echo $atts['css-class']; ?> <?php echo $atts['custom-css-class']; ?>"
			<?php echo ! empty( $atts['custom-id'] ) ? "id='{$atts['custom-id']}'" : ''; ?>
		>
			<?php

			bf_shortcode_show_title( $atts ); // show title

			// Custom and Auto Generated CSS Codes
			if ( ! empty( $atts['css-code'] ) ) {
				bf_add_css( $atts['css-code'], TRUE, TRUE );
			}

			foreach ( $attrs as $attr_id => $attr ) {
				$attr_string .= $attr != '' ? sprintf( ' %s="%s"', $attr_id, is_array( $attr ) ? implode( ' ', $attr ) : $attr ) : ' ' . $attr_id;
			}

			?>
			<div <?php echo $attr_string; ?> >
				<div class="bsfp-list-inner bsfp-clearfix">
					<?php

					bsfp_load_view(
						"widget/{$atts['style']}",
						compact( 'atts', 'api' ),
						array(
							'echo' => TRUE
						)
					);

					?>
				</div>
			</div>
		</div>
		<?php

		return ob_get_clean();
	} // display


	/**
	 * Fields of VC
	 *
	 * @return array
	 */
	public function get_fields() {

		$fields = array(
			array(
				'type' => 'tab',
				'name' => __( 'Style', 'better-studio' ),
				'id'   => 'style_tab',
			),
			array(
				'name'             => __( 'Style', 'better-studio' ),
				'id'               => 'style',
				'type'             => 'select_popup',
				'deferred-options' => array(
					'callback' => 'bsfp_stockmarket_widget_styles_option',
				),
				'texts'            => array(
					'modal_title'   => __( 'Choose Style', 'better-studio' ),
					'box_pre_title' => __( 'Active style', 'better-studio' ),
					'box_button'    => __( 'Change Style', 'better-studio' ),
				),
				'section_class'    => 'bsfp-style-field',
				'column_class'     => 'four-column',
				//
				'vc_admin_label'   => TRUE,
			),
			array(
				'name'             => __( 'Items Align', 'better-studio' ),
				'id'               => 'align',
				'type'             => 'select_popup',
				'deferred-options' => array(
					'callback' => 'bsfp_widgets_style_align_option',
				),
				'texts'            => array(
					'modal_title'   => __( 'Choose align', 'better-studio' ),
					'box_pre_title' => __( 'Active align', 'better-studio' ),
					'box_button'    => __( 'Change align', 'better-studio' ),
				),
				'section_class'    => 'bsfp-align-field',
				//
				'column_class'     => 'three-column',
			),
			array(
				'name'           => __( 'Columns', 'better-studio' ),
				'id'             => 'columns',
				'type'           => 'select',
				'options'        => array(
					1  => __( '1 Column', 'better-studio' ),
					2  => __( '2 Column', 'better-studio' ),
					3  => __( '3 Column', 'better-studio' ),
					4  => __( '4 Column', 'better-studio' ),
					5  => __( '5 Column', 'better-studio' ),
					6  => __( '6 Column', 'better-studio' ),
					7  => __( '7 Column', 'better-studio' ),
					8  => __( '8 Column', 'better-studio' ),
					9  => __( '9 Column', 'better-studio' ),
					10 => __( '10 Column', 'better-studio' ),
				),
				'show_on'        => array(
					array(
						'align=columned',
					)
				),
				//
				'vc_admin_label' => FALSE,
			),
			array(
				'name'           => __( 'Color Scheme', 'better-studio' ),
				'id'             => 'scheme',
				'type'           => 'select',
				'options'        => array(
					'light' => __( 'Light (White Skin)', 'better-studio' ),
					'dark'  => __( 'Dark (Black Skin)', 'better-studio' ),
				),
				//
				'vc_admin_label' => FALSE,
			),
			array(
				'type' => 'tab',
				'name' => __( 'Stock Market & Currency', 'better-studio' ),
				'id'   => 'stocks',
			),
			array(
				'name'           => __( 'Stock Market Type', 'better-studio' ),
				'id'             => 'stocks',
				'type'           => 'select',
				'options'        => array(
					'top-x-stocks' => __( 'Top X Popular Stock Markets', 'better-studio' ),
					'selected'     => __( 'Manually Selected Stock Markets', 'better-studio' ),
				),
				//
				'vc_admin_label' => FALSE,
			),
			array(
				'name'           => __( 'Stock Markets Count', 'better-studio' ),
				'id'             => 'stocks-count',
				'type'           => 'text',
				'show_on'        => array(
					array(
						'stocks=top-x-stocks',
					)
				),
				//
				'vc_admin_label' => FALSE,
			),
			array(
				'name'           => __( 'Select Stock Market', 'better-studio' ),
				'id'             => 'stocks-selected',
				'type'           => 'ajax_select',
				'get_name'       => 'bsfp_stock_market_select_callback_name',
				'callback'       => 'bsfp_stock_market_select_callback',
				'show_on'        => array(
					array(
						'stocks=selected',
					)
				),
				//
				'vc_admin_label' => FALSE,
			),
			array(
				'name'             => __( 'Currency', 'better-studio' ),
				'id'               => 'currency',
				'type'             => 'select',
				'deferred-options' => array(
					'callback' => 'bsfp_get_currencies_list_option',
				),
				//
				'vc_admin_label'   => TRUE,
			),
		);


		/**
		 * Retrieve heading fields from outside (our themes are defining them)
		 */
		{
			$heading_fields = apply_filters( 'better-framework/shortcodes/heading-fields', array(), $this->id );

			if ( $heading_fields ) {
				$fields = array_merge( $heading_fields, $fields );
			}
		}


		/**
		 * Retrieve design fields from outside (our themes are defining them)
		 */
		{
			$design_fields = apply_filters( 'better-framework/shortcodes/design-fields', array(), $this->id );

			if ( $design_fields ) {
				$fields = array_merge( $fields, $design_fields );
			}
		}

		return $fields;
	}


	/**
	 * Registers Visual Composer Add-on
	 */
	function register_vc_add_on() {

		vc_map( array(
			'name'           => __( 'Stock Market Widget', 'better-studio' ),
			"base"           => $this->id,
			"weight"         => 10,
			"wrapper_height" => 'full',

			"category" => __( 'Financial Pack', 'better-studio' ),
			"params"   => $this->vc_map_listing_all(),
		) );

	} // register_vc_add_on

}


/**
 * BS FP StockMarket Widget
 */
class BSFP_StockMarket_Widget extends BF_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {

		parent::__construct(
			'bsfp-stockmarket',
			__( 'FP - Stock Market', 'better-studio' ),
			array(
				'description' => __( 'Stock Market widget', 'better-studio' )
			)
		);
	} // __construct


	/**
	 * Loads fields
	 */
	function load_fields() {

		// Back end form fields
		$this->fields = array(
			array(
				'name' => __( 'Title', 'better-studio' ),
				'id'   => 'title',
				'type' => 'text',
			),
			//
			array(
				'type'  => 'group',
				'name'  => __( 'Style', 'better-studio' ),
				'id'    => 'style_tab',
				'state' => 'close',
			),
			array(
				'name'             => __( 'Style', 'better-studio' ),
				'id'               => 'style',
				'type'             => 'select_popup',
				'deferred-options' => array(
					'callback' => 'bsfp_stockmarket_widget_styles_option',
				),
				'texts'            => array(
					'modal_title'   => __( 'Choose Style', 'better-studio' ),
					'box_pre_title' => __( 'Active style', 'better-studio' ),
					'box_button'    => __( 'Change Style', 'better-studio' ),
				),
				'section_class'    => 'bsfp-style-field',
				'column_class'     => 'four-column',
			),
			array(
				'name'             => __( 'Items Align', 'better-studio' ),
				'id'               => 'align',
				'type'             => 'select_popup',
				'deferred-options' => array(
					'callback' => 'bsfp_widgets_style_align_option',
				),
				'texts'            => array(
					'modal_title'   => __( 'Choose align', 'better-studio' ),
					'box_pre_title' => __( 'Active align', 'better-studio' ),
					'box_button'    => __( 'Change align', 'better-studio' ),
				),
				'section_class'    => 'bsfp-align-field',
				'column_class'     => 'three-column',
			),
			array(
				'name'    => __( 'Columns', 'better-studio' ),
				'id'      => 'columns',
				'type'    => 'select',
				'options' => array(
					1  => __( '1 Column', 'better-studio' ),
					2  => __( '2 Column', 'better-studio' ),
					3  => __( '3 Column', 'better-studio' ),
					4  => __( '4 Column', 'better-studio' ),
					5  => __( '5 Column', 'better-studio' ),
					6  => __( '6 Column', 'better-studio' ),
					7  => __( '7 Column', 'better-studio' ),
					8  => __( '8 Column', 'better-studio' ),
					9  => __( '9 Column', 'better-studio' ),
					10 => __( '10 Column', 'better-studio' ),
				),
				'show_on' => array(
					array(
						'align=columned',
					)
				),
			),
			array(
				'name'    => __( 'Color Scheme', 'better-studio' ),
				'id'      => 'scheme',
				'type'    => 'select',
				'options' => array(
					'light' => __( 'Light (White Skin)', 'better-studio' ),
					'dark'  => __( 'Dark (Black Skin)', 'better-studio' ),
				),
			),
			//
			array(
				'type'  => 'group',
				'name'  => __( 'Stock Market & Currency', 'better-studio' ),
				'id'    => 'stocks',
				'state' => 'close',
			),
			array(
				'name'    => __( 'Stock Market Type', 'better-studio' ),
				'id'      => 'stocks',
				'type'    => 'select',
				'options' => array(
					'top-x-stocks' => __( 'Top X Popular Stock Markets', 'better-studio' ),
					'selected'     => __( 'Manually Selected Stock Markets', 'better-studio' ),
				),
			),
			array(
				'name'    => __( 'Stock Markets Count', 'better-studio' ),
				'id'      => 'stocks-count',
				'type'    => 'text',
				'show_on' => array(
					array(
						'stocks=top-x-stocks',
					)
				),
			),
			array(
				'name'     => __( 'Select Stock Market', 'better-studio' ),
				'id'       => 'stocks-selected',
				'type'     => 'ajax_select',
				'get_name' => 'bsfp_stock_market_select_callback_name',
				'callback' => 'bsfp_stock_market_select_callback',
				'show_on'  => array(
					array(
						'stocks=selected',
					)
				),
			),
			array(
				'name'             => __( 'Currency', 'better-studio' ),
				'id'               => 'currency',
				'type'             => 'select',
				'deferred-options' => array(
					'callback' => 'bsfp_get_currencies_list_option',
				),
			),
		);
	} // load_fields
}
