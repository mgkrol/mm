<?php
/**
 * Type 13 => Style 0
 *
 * @var $atts
 * @var $api
 */

$data = $api->get( array(
	'prices'          => array(),
	'changes_average' => array(),
) );

if ( empty( $data ) ) {

	bsfp_print_error();

	return;
}

foreach ( $data as $symbol => $item ) {

	$currency   = $item['main_currency'];
	$title_attr = $item['name'];

	?>
	<div class='bs-fp bs-fp-20 bs-fp-t13 bs-fp-s0'>
		<div class="bs-fp-inner bsfp-clearfix">
			<div class="fp-name" title="<?php echo $title_attr; ?>"><?php echo $symbol; ?>
				/ <?php echo $currency; ?></div>

			<?php if ( isset( $item['prices'][ $currency ] ) ) { ?>
				<div class="fp-price"><?php echo bsfp_format_currency( $item['prices'][ $currency ], $currency, FALSE ); ?></div>
			<?php } ?>

			<div class="fp-text">
				<?php if ( ! empty( $item['changes_average'][ $currency ] ) ) { ?>
					<?php if ( $arrow = bsfp_get_arrow_class( $item, $currency, 'style-4' ) ) {
						?>
						<span class="fp-arrow fp-<?php echo $item['changes_average'][ $currency ]['state']; ?> <?php echo $arrow; ?>"></span>
						<?php
					} ?>

					<div class="fp-changes fp-changes-percentage fp-<?php echo $item['changes_average'][ $currency ]['state']; ?>">
						<?php echo bsfp_format_percentage( $item['changes_average'][ $currency ]['percentage'], 2, TRUE, FALSE ); ?>
					</div>
					<div class="fp-changes fp-changes-point fp-<?php echo $item['changes_average'][ $currency ]['state']; ?>">
						(<?php echo bsfp_format_percentage(
							$item['changes_average'][ $currency ]['value'],
							2,
							FALSE,
							TRUE
						); ?>)
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
<?php } ?>
