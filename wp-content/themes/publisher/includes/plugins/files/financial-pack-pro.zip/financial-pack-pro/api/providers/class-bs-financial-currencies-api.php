<?php


class BS_Financial_Currencies_API extends BS_Financial_Currency_Service {

	/**
	 * @var string
	 */
	public $base_url = 'http://currencies.apps.grandtrunk.net/getrange/';


	/**
	 * Requests queue
	 *
	 * @var array
	 */
	protected $queue = array();

	/**
	 * Store currency info
	 *
	 * @var array
	 */
	protected $rates = array();

	/**
	 * Store early loaded data
	 *
	 * @var array
	 */
	protected $data = array();


	/**
	 * Is api ready to use
	 *
	 * @return bool
	 */
	public function ready() {

		return bsfp_is_host_accessible( 'http://currencies.apps.grandtrunk.net/' );
	}


	/**
	 * Fetch list of items price
	 *
	 * @return bool always true
	 */
	protected function fetch_prices() {

		$this->queue[] = 'prices';

		return TRUE;
	}


	/**
	 * Get amount of changes in last 24 hour
	 *
	 * @return bool always true
	 */
	protected function fetch_changes_average() {

		$this->queue[] = 'changes_average';

		return TRUE;
	}


	/**
	 * Get list of items logo
	 *
	 * @return bool always true
	 * @throws Exception
	 */
	protected function fetch_logo() {

		$logo = array();

		$logo_url = BS_Financial_Pack_Pro::dir_url( '/img/currencies/%s.svg' );

		foreach ( $this->get_currencies() as $currency ) {


			$logo[ $currency ] = sprintf( $logo_url, $currency );
		}

		$this->data['logo'] = $logo;
	}


	/**
	 * Daily history of price changes in given timestamp range
	 *
	 * @return bool always true
	 */
	protected function fetch_daily_history() {


		$this->queue[] = 'daily_history';


		return TRUE;
	}


	/**
	 * Get list of available item
	 *
	 * @return bool true on success
	 * @throws Exception
	 */
	function fetch_items_list() {

		throw new Exception( 'currencies list not supported' );
	}


	/**
	 * Hourly history of price changes in given timestamp range
	 *
	 * @return bool true on success or false failure.
	 * @throws Exception
	 */
	protected function fetch_hourly_history() {

		throw new Exception( 'hourly history not supported' );


	}


	/**
	 * ‌Get item statistics data
	 *
	 * @return bool true on success or false failure.
	 * @throws Exception
	 */
	protected function fetch_statistics() {

		$this->queue[] = 'statistics';

		return TRUE;
	}


	/**
	 * Request Results
	 *
	 * @return array|bool false on failure.
	 */
	protected function get_results() {

		$results     = $this->data;
		$this->rates = bsfp_get_exchange_rate( $this->get_currencies(), $this->base_currency, TRUE );

		$history = array();

		if ( in_array( 'daily_history', $this->queue ) ) {

			$history = $this->request_daily_history();

			$results['daily_history'] = $this->format_history( $history );
		}

		if ( in_array( 'changes_average', $this->queue ) ) {

			if ( empty( $history ) ) {
				$history = $this->request_daily_history( '2' );
			}

			$results['changes_average'] = $this->calc_statistics( $history );
		}

		if ( in_array( 'prices', $this->queue ) ) {

			if ( empty( $history ) ) {
				$history = $this->request_daily_history( '1' );
			}

			$results['prices'] = $this->filter_prices( $history );
		}

		return $results;
	}


	/**
	 * Get item name
	 *
	 * @param string $id
	 *
	 * @return string
	 */
	protected function get_name( $id ) {

		if ( isset( $this->rates[ $id ]['name'] ) ) {
			return $this->rates[ $id ]['name'];
		}

		return '';
	}


	/**
	 * @param string $start_day
	 *
	 * @return array
	 */
	protected function request_daily_history( $start_day = '30' ) {

		$start   = date( 'Y-m-d', strtotime( "-$start_day days" ) );
		$end     = date( 'Y-m-d' );
		$results = array();

		foreach ( $this->get_currencies() as $currency ) {

			if ( $this->base_currency === $currency ) {
				continue;
			}

			$url = sprintf(
				'http://currencies.apps.grandtrunk.net/getrange/%s/%s/%s/%s',
				$start,
				$end,
				$this->base_currency,
				$currency
			);

			$response = BS_Financial_Pack_Pro_Utilities::request( $url, array(), TRUE );

			if ( empty( $response ) ) {
				continue;
			}

			$results[ $currency ] = $this->parse_response( $response );

		}

		return $results;
	}


	/**
	 * @param string $response
	 *
	 * @return array
	 */
	protected function parse_response( $response ) {

		$results = array();

		foreach ( explode( "\n", $response ) as $item ) {

			if ( empty( $item ) ) {
				continue;
			}

			list( $time, $value ) = explode( ' ', $item );


			$results[ strtotime( "$time 00:00:00" ) ] = floatval( $value );
		}

		return $results;
	}


	/**
	 * Calculate statistics info from historical price
	 *
	 * @param $daily_history
	 *
	 * @return array|bool
	 */
	protected function calc_statistics( $daily_history ) {

		if ( empty( $daily_history ) ) {
			return FALSE;
		}

		$rates   = bsfp_get_exchange_rate( $this->get_items(), $this->base_currency );
		$results = array();

		foreach ( $daily_history as $currency => $changes ) {

			$yesterday    = array_pop( $changes );
			$two_days_ago = array_pop( $changes );

			if ( $yesterday === $two_days_ago ) {

				$two_days_ago = array_pop( $changes );
			}


			foreach ( $rates as $rate_currency => $rate ) {

				$value      = ( $rate / $yesterday ) - ( $rate / $two_days_ago );
				$percentage = ( ( $yesterday * 100 ) / $two_days_ago ) - 100;

				if ( $value === 0.0 || $value === 0 ) {

					$state = 'fixed';

				} else {

					$state = $value > 0 ? 'up' : 'down';
				}

				$results[ $currency ][ $rate_currency ]['percentage'] = $percentage;
				$results[ $currency ][ $rate_currency ]['value']      = $value;
				$results[ $currency ][ $rate_currency ]['state']      = $state;
			}
		}


		return $results;
	}


	/**
	 * Get latest currencies price
	 *
	 * @param $daily_history
	 *
	 * @return array|bool
	 */
	protected function filter_prices( $daily_history ) {

		if ( empty( $daily_history ) ) {
			return FALSE;
		}

		$results = array();

		foreach ( $daily_history as $currency => $changes ) {

			$results[ $currency ] = $this->format_value( array_pop( $changes ) );
		}

		return $results;
	}
}