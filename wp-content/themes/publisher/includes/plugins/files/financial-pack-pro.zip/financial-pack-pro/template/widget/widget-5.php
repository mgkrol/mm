<?php
/**
 * Type 2 => Style 0
 *
 * @var $atts
 * @var $api
 */

$data = $api->get( array(
	'prices'          => array(),
	'changes_average' => array(),
	'logo'            => array(),
) );


if ( empty( $data ) ) {

	bsfp_print_error();

	return;
}

foreach ( $data as $symbol => $item ) {

	$currency   = $item['main_currency'];
	$title_attr = $item['name'];

	?>
	<div class='bs-fp bs-fp-5 bs-fp-t2 bs-fp-s0'>
		<div class="bs-fp-inner bsfp-clearfix">
			<?php if ( ! empty( $item['logo'] ) ) { ?>
				<div class="fp-logo">
					<img alt="<?php echo $title_attr; ?>" src="<?php echo $item['logo']; ?>">
				</div>
			<?php } ?>

			<div class="fp-text">
				<div class="fp-name" title="<?php echo $title_attr; ?>"><?php echo $symbol; ?></div>

				<?php if ( isset( $item['prices'][ $currency ] ) ) { ?>
					<div class="fp-price"><?php echo bsfp_format_currency( $item['prices'][ $currency ], $currency ); ?></div>
				<?php } ?>

				<?php if ( $arrow = bsfp_get_arrow_class( $item, $currency, 'style-1' ) ) {
					?>
					<span class="fp-arrow fp-<?php echo $item['changes_average'][ $currency ]['state']; ?> <?php echo $arrow; ?>"></span>
					<?php
				} ?>
			</div>
		</div>
	</div>
<?php } ?>
