<?php
/**
 * Type 4 => Style 0
 *
 * @var $atts
 * @var $api
 */

$data = $api->get( array(
	'prices'          => array(),
	'changes_average' => array(),
) );

if ( empty( $data ) ) {

	bsfp_print_error();

	return;
}

foreach ( $data as $symbol => $item ) {

	$currency   = $item['main_currency'];
	$title_attr = $symbol;
	$_check     = array(
		'currency'     => '',
		'stock-market' => '',
	);

	if ( isset( $_check[ $atts['data-type'] ] ) ) {
		$name       = $symbol;
		$title_attr = $item['name'];
	} else {
		$name = $item['name'];
	}

	?>
	<div class='bs-fp bs-fp-11 bs-fp-t4 bs-fp-s0'>
		<div class="bs-fp-inner">
			<div class="fp-name" title="<?php echo $title_attr; ?>"><?php echo $name; ?></div>

			<?php if ( $arrow = bsfp_get_arrow_class( $item, $currency, 'style-2' ) ) {
				?>
				<span class="fp-arrow fp-<?php echo $item['changes_average'][ $currency ]['state']; ?> <?php echo $arrow; ?>"></span>
				<?php
			} ?>

			<?php if ( isset( $item['prices'][ $currency ] ) ) { ?>
				<div class="fp-price"><?php echo $currency, ' ', bsfp_format_currency( $item['prices'][ $currency ], $currency, FALSE ); ?></div>
			<?php } ?>

		</div>
	</div>
<?php }
