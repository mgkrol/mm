<?php


class BS_Financial_IexTrading_API extends BS_Financial_Stock_Service {

	/**
	 * @var string
	 */
	public $base_url = 'https://api.iextrading.com/1.0/';


	/**
	 * Requests queue
	 *
	 * @var array
	 */
	protected $queue = array();


	/**
	 * Iex Request types
	 *
	 * @var array
	 */
	protected $types = array();


	/**
	 * Store list of companies name
	 *
	 * @var array
	 */
	protected $names = array();


	/**
	 * Store iex request response
	 *
	 * @var array
	 */
	protected $response = array();


	/**
	 * @var string
	 */
	protected $range;


	/**
	 * Local logo list
	 *
	 * @var array
	 */
	public $local_logo = array(
		'AAPL',
		'ABBV',
		'ABT',
		'ACN',
		'ADBE',
		'AMGN',
		'AMZN',
		'AVGO',
		'BA',
		'BABA',
		'BAC',
		'BHP',
		'BIDU',
		'BKNG',
		'BLK',
		'BMY',
		'BP',
		'BRK.B',
		'BTI',
		'BUD',
		'C',
		'CAT',
		'CHL',
		'CMCSA',
		'CRM',
		'CSCO',
		'DCM',
		'DIS',
		'DWDP',
		'FB',
		'GE',
		'GILD',
		'GOOG',
		'GOOGL',
		'GS',
		'GSK',
		'HD',
		'HON',
		'HSBC',
		'IBM',
		'INTC',
		'ITUB',
		'JNJ',
		'JPM',
		'KO',
		'LFC',
		'LLY',
		'LMT',
		'MA',
		'MCD',
		'MDT',
		'MMM',
		'MO',
		'MRK',
		'MS',
		'MSFT',
		'MTU',
		'NFLX',
		'NKE',
		'NVDA',
		'NVO',
		'NVS',
		'ORCL',
		'PBR',
		'PEP',
		'PFE',
		'PG',
		'PM',
		'PTR',
		'PYPL',
		'QCOM',
		'RDS.A',
		'RDS.B',
		'RIO',
		'RY',
		'SAN',
		'SAP',
		'SNP',
		'SNY',
		'T',
		'TD',
		'TM',
		'TOT',
		'TSM',
		'TXN',
		'UL',
		'UN',
		'UNH',
		'UNP',
		'UPS',
		'USB',
		'UTX',
		'V',
		'VZ',
		'WFC',
		'WMT',
		'XOM',
	);


	/**
	 * Is api ready to use
	 *
	 * @return bool
	 */
	public function ready() {

		return bsfp_is_host_accessible( 'https://api.iextrading.com/1.0/stock/aapl/company' );
	}


	/**
	 * Fetch list of items price
	 *
	 * @return bool always true
	 */
	protected function fetch_prices() {

		$this->queue[] = 'prices';
		$this->types[] = 'quote';

		return TRUE;
	}


	/**
	 * Get amount of changes in last 24 hour
	 *
	 * @return bool always true
	 */
	protected function fetch_changes_average() {

		$this->queue[] = 'changes_average';
		$this->types[] = 'quote';

		return TRUE;
	}


	/**
	 * Get list of items logo
	 *
	 * @return bool always true
	 */
	protected function fetch_logo() {

		$this->queue[] = 'logo';
		$this->types[] = 'logo';

		return TRUE;
	}


	/**
	 * Daily history of price changes in given timestamp range
	 *
	 * @return bool always true
	 */
	protected function fetch_daily_history() {

		$this->queue[] = 'daily_history';
		$this->types[] = 'chart';
		$this->range   = '3m';

		return TRUE;
	}


	/**
	 * @param array $items
	 *
	 * @access internal
	 * @return array|bool false on failure
	 */
	protected function prepare_history_items( array $items ) {

		$time_series = array();

		foreach ( $items as $item ) {

			$date = $item['date'];

			if ( ! empty( $item['minute'] ) ) {

				$date .= sprintf( ' %s:00', $item['minute'] );
			}

			$value = NULL;

			if ( isset( $item['close'] ) ) {

				$value = $item['close'];

			} elseif ( isset( $item['marketAverage'] ) ) {

				$value = $item['marketAverage'];

			} elseif ( isset( $item['average'] ) ) {

				$value = $item['average'];
			}

			if ( isset( $value ) ) {

				$time_series[ strtotime( $date ) ] = $value;
			}
		}

		if ( ! empty( $time_series ) ) {

			return $time_series;
		}

		return FALSE;
	}


	/**
	 * Hourly history of price changes in given timestamp range
	 *
	 * @return array|bool false on failure
	 */
	protected function fetch_hourly_history() {

		$this->queue[] = 'daily_history';
		$this->types[] = 'chart';
		$this->range   = '1d';

		return TRUE;
	}


	/**
	 * ‌Get item statistics data
	 *
	 * @return array|bool false on failure
	 */
	protected function fetch_statistics() {

		$this->queue[] = 'statistics';
		$this->types[] = 'stats';

		return TRUE;
	}


	/**
	 * Get api url
	 *
	 * @param string $endpoint
	 * @param array  $queries
	 *
	 * @return string
	 */
	public function url( $endpoint, array $queries = array() ) {

		$url = trailingslashit( $this->base_url ) . $endpoint;

		return $url . '?' . http_build_query( $queries );
	}


	/**
	 * @param int $from start timestamp
	 * @param int $to   end   timestamp
	 *
	 * @return string
	 */
	protected function calc_iex_time_range( $from, $to ) {

		$diff      = absint( $to - $from );
		$iex_range = '';

		if ( $diff < WEEK_IN_SECONDS ) {

			// Days
			$piece = max( 1, $diff / DAY_IN_SECONDS );

			if ( $piece <= 1 ) {

				$iex_range = '1d';

			} else {

				$iex_range = '1m';
			}

		} elseif ( $diff < YEAR_IN_SECONDS && $diff >= MONTH_IN_SECONDS ) {

			// Month
			$piece = max( 1, $diff / MONTH_IN_SECONDS );

			if ( $piece > 6 ) {

				$iex_range = '1y';

			} elseif ( $piece > 3 ) {

				$iex_range = '6m';

			} elseif ( $piece > 1 ) {

				$iex_range = '1m';
			} else {

				$iex_range = '1m';
			}

		} elseif ( $diff >= YEAR_IN_SECONDS ) {

			// Years
			$piece = max( 1, $diff / YEAR_IN_SECONDS );

			if ( $piece > 2 ) {

				$iex_range = '5y';

			} elseif ( $piece > 1 ) {

				$iex_range = '2y';

			} else {

				$iex_range = '1y';
			}
		}

		return $iex_range;
	}


	/**
	 * Get list of available item
	 *
	 * @return bool true on success
	 */
	function fetch_items_list() {

		$url = $this->url( 'ref-data/symbols' );

		if ( ! $response = BS_Financial_Pack_Pro_Utilities::request( $url ) ) {

			return FALSE;
		}

		if ( ! is_array( $response ) ) {
			return FALSE;
		}

		$items = array();

		foreach ( $response as $item ) {

			$symbol = $item['symbol'];

			$items[ $symbol ] = array(
				'name'        => $item['name'],
				'symbol'      => $item['symbol'],
				'is_trending' => ! empty( $item['isEnabled'] ),

			);
		}

		if ( ! empty( $items ) ) {
			return $items;
		}


		return FALSE;
	}


	/**
	 * Request Results
	 *
	 * @return array
	 * @throws Exception
	 */
	protected function get_results() {

		$this->types[] = 'quote';

		$url = $this->url( 'stock/market/batch', array(
			'range'   => $this->range,
			'types'   => implode( ',', array_unique( $this->types ) ),
			'symbols' => implode( ',', $this->config['items'] ),
		) );

		if ( ! $this->response = BS_Financial_Pack_Pro_Utilities::request( $url ) ) {

			return FALSE;
		}

		$results = array();

		if ( in_array( 'prices', $this->queue ) ) {

			$results['prices'] = $this->filter_prices();
		}

		if ( in_array( 'changes_average', $this->queue ) ) {

			$results['changes_average'] = $this->filter_changes_average();
		}

		if ( in_array( 'logo', $this->queue ) ) {

			$results['logo'] = $this->filter_logos();
		}

		if ( in_array( 'daily_history', $this->queue ) ) {

			$results['daily_history'] = $this->filter_daily_history();
		}
		if ( in_array( 'statistics', $this->queue ) ) {

			$results['statistics'] = $this->filter_statistics();
		}

		if ( empty( $this->names ) ) {
			$this->collect_names();
		}


		return $results;
	}


	/**
	 * Grab prices from batch request
	 *
	 * @return array
	 * @throws Exception
	 */
	protected function filter_prices() {

		$prices = array();

		foreach ( $this->response as $symbol => $info ) {

			if ( empty( $info['quote'] ) ) {
				continue;
			}

			$this->names[ $symbol ] = $info['quote']['companyName'];

			$prices[ $symbol ] = $this->format_value(
				empty( $info['quote']['latestPrice'] ) ? $info['quote']['delayedPrice'] : $info['quote']['latestPrice']
			);
		}

		return $prices;
	}


	protected function filter_changes_average() {

		$changes = array();

		foreach ( $this->response as $symbol => $info ) {

			if ( empty( $info['quote'] ) ) {
				continue;
			}

			$this->names[ $symbol ] = $info['quote']['companyName'];

			$value      = floatval( $info['quote']['change'] );
			$percentage = $info['quote']['changePercent'] * 100;

			$changes[ $symbol ] = $this->format_changes( $value, $percentage );
		}

		return $changes;
	}


	protected function filter_logos() {

		$logos = array();
		//
		$local_logo_url = BS_Financial_Pack_Pro::dir_url( '/img/stocks/%code%.svg' );

		foreach ( $this->response as $symbol => $info ) {

			if ( in_array( $symbol, $this->local_logo ) ) {

				$logos[ $symbol ] = str_replace( '%code%', strtolower( $symbol ), $local_logo_url );

			} elseif ( ! empty( $info['logo']['url'] ) ) {

				$logos[ $symbol ] = $info['logo']['url'];
			}

		}

		return $logos;
	}


	protected function filter_daily_history() {

		$result = array();

		foreach ( $this->response as $symbol => $info ) {

			if ( empty( $info['chart'] ) ) {
				continue;
			}

			$result[ $symbol ] = $this->format_value_list(
				$this->prepare_history_items( $info['chart'] )
			);
		}

		return $result;
	}


	protected function filter_statistics() {

		$stats = array();

		foreach ( $this->response as $symbol => $info ) {

			if ( empty( $info['stats'] ) ) {
				continue;
			}

			$stats[ $symbol ] = $this->format_value_list( array(
				'profit_margin' => $info['stats']['profitMargin'],
				'market_cap'    => $info['stats']['marketcap'],
				'revenue'       => $info['stats']['revenue'],
			), array( 'profit_margin' ) );
		}

		return $stats;
	}


	/**
	 * Request Results
	 *
	 * @param string $id
	 *
	 * @return array
	 */
	protected function get_name( $id ) {

		if ( isset( $this->names[ $id ] ) ) {
			return $this->names[ $id ];
		}

		return '';
	}


	protected function collect_names() {

		foreach ( $this->response as $symbol => $info ) {

			if ( empty( $info['quote'] ) ) {
				continue;
			}

			$this->names[ $symbol ] = $info['quote']['companyName'];
		}
	}
}