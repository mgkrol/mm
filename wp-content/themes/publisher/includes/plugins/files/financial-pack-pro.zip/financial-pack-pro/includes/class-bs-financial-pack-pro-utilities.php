<?php


class BS_Financial_Pack_Pro_Utilities {

	/**
	 * Request and fetch data from an api endpoint
	 *
	 * @param string $endpoint_url
	 * @param array  $args
	 * @param bool   $raw_data
	 *
	 * @return array|string
	 */
	public static function request( $endpoint_url, $args = array(), $raw_data = FALSE ) {

		$args   = bf_merge_args( $args, array( 'timeout' => bf_is_localhost() ? 10 : 2, 'sslverify' => FALSE ) );
		$remote = wp_remote_get( $endpoint_url, $args );

		if ( ! $remote || is_wp_error( $remote ) ) {
			return array();
		}

		if ( wp_remote_retrieve_response_code( $remote ) !== 200 ) {
			return array();
		}

		$response = wp_remote_retrieve_body( $remote );

		if ( ! $raw_data ) {
			$response = json_decode( $response, TRUE );
		}

		return $response;
	}

}
