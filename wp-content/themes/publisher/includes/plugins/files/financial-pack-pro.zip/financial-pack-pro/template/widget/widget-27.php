<?php
/**
 * Type 20 => Style 0
 *
 * @var $atts
 * @var $api
 */

$data = $api->get( array(
	'logo'            => array(),
	'prices'          => array(),
	'changes_average' => array(),
	'daily_history'   => array(),
) );

if ( empty( $data ) ) {

	bsfp_print_error();

	return;
}

?>
<div class='bs-fp bs-fp-27 bs-fp-t20 bs-fp-s0'>
	<?php

	foreach ( $data as $symbol => $item ) {

		$currency   = $item['main_currency'];
		$title_attr = $symbol;

		?>
		<div class="fp-tr-table">
			<div class="fp-td-name">
				<span class="fp-name" title="<?php echo $title_attr; ?>"><?php echo $item['name'] ?></span>

				<?php if ( isset( $item['prices'][ $currency ] ) ) { ?>
					<span class="fp-price"><?php echo bsfp_format_currency( $item['prices'][ $currency ], $currency ); ?></span>
				<?php } ?>
			</div>

			<div class="fp-td-changes">
				<?php if ( ! empty( $item['changes_average'][ $currency ] ) ) { ?>
					<span class="fp-changes fp-<?php echo $item['changes_average'][ $currency ]['state']; ?>"><?php echo bsfp_format_percentage( $item['changes_average'][ $currency ]['percentage'] ); ?></span>
					<span class="fp-changes fp-<?php echo $item['changes_average'][ $currency ]['state']; ?>"><?php echo bsfp_format_percentage( $item['changes_average'][ $currency ]['value'], 2, FALSE ); ?></span>
				<?php } ?>
			</div>

			<?php if ( isset( $item['daily_history'][ $currency ] ) ) { ?>
				<div class="visualization">
					<div class="ct-chart bs-fp-chart-list fp-<?php echo ! empty( $item['changes_average'][ $currency ] ) ? $item['changes_average'][ $currency ]['state'] : 'fixed'; ?>"
					     data-series="<?php echo implode( ',', $item['daily_history'][ $currency ] ) ?>"
					     data-width="100px"
					     data-height="26px"
					></div>
				</div>
			<?php } ?>
		</div>
	<?php } ?>
</div>
