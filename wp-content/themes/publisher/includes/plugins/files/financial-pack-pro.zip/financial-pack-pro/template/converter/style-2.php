<?php
/**
 * Type 1 => Style 2
 *
 * @var $atts
 */
?>
<div class='bs-fpc bs-fpc-2 bs-fpc-t1 bs-fpc-s1'>
	<div class="fpc-from-currency-label">
		<span class="value"></span> <span class="unit bsf-currency-code"><?php echo $atts['from_currency'] ?></span> =
	</div>
	<span class="fpc-to-currency-label">
		<span class="value"></span> <span class="unit bsf-currency-code"><?php echo $atts['to_currency'] ?></span>
	</span>
	<form class="fpc-form">

		<div class="fpc-input-section bsfp-clearfix">
			<div class="fpc-field bsfp-clearfix">
				<input type="text" class="fpc-input fpc-convert-from" value="1">
			</div>
			<div class="fpc-field fpc-field-uni  bsfp-clearfix">
				<div class="fpc-select-field">
					<img class="fpc-crypto-icon fpc-from-currency-icon" src="<?php echo $atts['from_currency_logo'] ?>">

					<?php

					bsfp_dropdown_helper( $atts['from_currencies'], array(
						'attrs'    => array(
							'class' => 'fpc-input fpc-from-unit',
						),
						'selected' => $atts['from_currency']
					) )
					?>
					<span class="fpc-select-arrow bsfi-arrow2-s"></span>
				</div>
			</div>
		</div>

		<a class="fpc-switch-arrow bsfi-arrow-up-down" href="#switch"></a>

		<div class="fpc-input-section bsfp-clearfix">
			<div class="fpc-field bsfp-clearfix">
				<input type="text" class="fpc-input fpc-convert-to" disabled>
			</div>
			<div class="fpc-field fpc-field-uni fpc-to-currency-field bsfp-clearfix">
				<div class="fpc-select-field">
					<img class="fpc-flag-icon fpc-to-currency-icon" src="<?php echo $atts['to_currency_logo'] ?>">
					<?php
					bsfp_dropdown_helper( $atts['to_currencies'], array(
						'attrs'    => array(
							'class' => 'fpc-input fpc-to-unit',
						),
						'selected' => $atts['to_currency']
					) )
					?>
					<span class="fpc-select-arrow bsfi-arrow2-s"></span>
				</div>
			</div>
		</div>
	</form>
</div>
