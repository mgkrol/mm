<?php


$abspath = realpath( str_repeat( '../', 5 ) );

require $abspath . '/wp-load.php';

/**
 * @var BS_Financial_Currency_Service $api
 */
$api = bsfp_api_instance( 'currencies' );

if ( ! $api ) {
	die( "<h1>Error :-/  cannot connect to grandtrunk.net</h1>" );
}


$api->set_units( array( 'USD', 'GBP' ) );
$api->set_currencies( array( 'IRR', 'EUR' ) );


$results = $api->get( array(
	'daily_history'   => array(), // arguments
	'changes_average' => array(),
	//		'statistics'      => array(),
	'logo'            => array(),
	'prices'          => array(),
) );

ini_set( 'xdebug.var_display_max_depth', 5 );
ini_set( 'xdebug.var_display_max_children', 256 );
ini_set( 'xdebug.var_display_max_data', 1024 );

bf_var_dump_exit( $results );
