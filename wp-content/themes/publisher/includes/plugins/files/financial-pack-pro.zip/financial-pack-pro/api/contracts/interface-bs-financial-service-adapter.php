<?php


interface BS_Financial_Service_Interface {

	/**
	 * Set service provider object
	 *
	 * @param BS_Financial_Service_Base $provider
	 */
	public function set_provider( BS_Financial_Service_Base $provider );

	/**
	 * @return BS_Financial_Service_Base
	 */
	public function get_provider();

	/**
	 * Access API Interface
	 *
	 * @param array $methods
	 *
	 * @return array
	 */
	public function get( array $methods );
}