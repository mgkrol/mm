<?php
/**
 * Type 19 => Style 0
 *
 * @var $atts
 * @var $api
 */

$data = $api->get( array(
	'logo'            => array(),
	'prices'          => array(),
	'changes_average' => array(),
) );

if ( empty( $data ) ) {

	bsfp_print_error();

	return;
}

?>
<div class='bs-fp bs-fp-26 bs-fp-t19 bs-fp-s0'>
	<?php

	foreach ( $data as $symbol => $item ) {

		$currency   = $item['main_currency'];
		$title_attr = $symbol;

		?>
		<div class="fp-tr-table">

			<div class="fp-td-name">

				<?php if ( ! empty( $item['logo'] ) ) { ?>
					<span class="fp-logo">
						<img alt="<?php echo $title_attr; ?>" src="<?php echo $item['logo'] ?>">
					</span>
				<?php } ?>

				<span class="fp-name" title="<?php echo $title_attr; ?>"><?php echo $item['name'] ?></span>
			</div>

			<?php if ( isset( $item['prices'][ $currency ] ) ) { ?>
				<div class="fp-td-price">
					<?php

					if ( $arrow = bsfp_get_arrow_class( $item, $currency, 'style-2' ) ) {
						?>
						<span class="fp-arrow fp-<?php echo $item['changes_average'][ $currency ]['state']; ?> <?php echo $arrow; ?>"></span>
						<?php
					}

					?>
					<span class="fp-price"><?php echo bsfp_format_currency( $item['prices'][ $currency ], $currency ); ?></span>
				</div>
			<?php } ?>

			<div class="fp-td-changes">
				<?php if ( ! empty( $item['changes_average'][ $currency ] ) ) { ?>
					<span class="fp-changes fp-<?php echo $item['changes_average'][ $currency ]['state']; ?>"><?php echo bsfp_format_percentage( $item['changes_average'][ $currency ]['percentage'] ); ?></span>
				<?php } ?>
			</div>
		</div>

	<?php } ?>
</div>
