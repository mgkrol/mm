<?php


if ( ! function_exists( 'bsfp_prepare_crypto_currency_exchange_data' ) ) {

	/**
	 * Generates the crypto exchange data for converter
	 *
	 * @return array|bool false on failure or array on success
	 * @throws \Exception
	 */
	function bsfp_prepare_crypto_currency_exchange_data() {

		if ( $cached = get_transient( 'fp_exchange_rate' ) ) {

			return $cached;
		}

		if ( ! $api = bsfp_api_instance( 'crypto_compare' ) ) {

			return FALSE;
		}

		if ( ! class_exists( 'BC_Financial_API_Exporter' ) ) {

			require BS_Financial_Pack_Pro::dir_path( 'api/adapters/class-bs-financial-api-exporter.php' );
		}

		$api_adapter = new BC_Financial_API_Exporter( $api );

		$api->set_currencies( array( 'usd' ) );
		$api->set_items( array_keys( bsfp_get_cryptocurrencies_list() ) );

		if ( ! $results = $api_adapter->get( array( 'prices' => array(), 'logo' => array() ) ) ) {
			return FALSE;
		}

		set_transient( 'fp_exchange_rate', $results, HOUR_IN_SECONDS );

		return $results;
	}
}


if ( ! function_exists( 'bsfp_get_exchange_rate' ) ) {
	/**
	 * Get cash exchange rate based un united states dollar
	 *
	 * @param array|string $currencies currencies code list as array or 'all' for all currencies
	 * @param string       $base_currency
	 * @param bool         $full_detail
	 *
	 * @throws Exception
	 * @return array
	 */
	function bsfp_get_exchange_rate( $currencies = 'all', $base_currency = 'USD', $full_detail = FALSE ) {

		$rates           = array();
		$currencies_list = bsfp_get_currencies_list();
		$base_currency   = strtoupper( $base_currency );

		if ( 'all' === $currencies ) {

			$filtered = &$currencies_list;

		} else {

			$currencies = array_map( 'strtoupper', $currencies );
			$currencies = array_flip( $currencies );
			$filtered   = array_intersect_key( $currencies_list, $currencies );
		}

		if ( 'USD' === $base_currency ) {

			$transform_factor = 1;

		} elseif ( isset( $currencies_list[ $base_currency ]['rate'] ) ) {

			$transform_factor = $currencies_list[ $base_currency ]['rate'];
		} else {

			return array();
		}

		foreach ( $filtered as $code => $info ) {

			$info['rate']   /= $transform_factor;
			$rates[ $code ] = $full_detail ? $info : $info['rate'];
		}


		return $rates;
	}
}


if ( ! function_exists( 'bsfp_filter_treading_item' ) ) {
	/**
	 * @access internal usage
	 *
	 * @param $item
	 *
	 * @return bool
	 */
	function bsfp_filter_treading_item( $item ) {

		return ! empty( $item['is_trending'] );
	}
}


if ( ! function_exists( 'bsfp_get_events' ) ) {
	/**
	 * Get events list from the source
	 *
	 * @param string $source bitcoin|cryptovest
	 *
	 * @return array|bool false on failure or array on success
	 */
	function bsfp_get_events( $source = 'bitcoin' ) {

		$cache_key = 'fp_' . $source . '_events';

		if ( $cached = get_transient( $cache_key ) ) {

			return $cached;
		}

		$data = FALSE;

		if ( 'bitcoin' === $source ) {

			$data = bsfp_get_bitcoin_events();

		} elseif ( 'cryptovest' === $source ) {

			$data = bsfp_get_cryptovest_events();

		}

		if ( $data === FALSE ) {

			return FALSE;
		}

		set_transient( $cache_key, $data, DAY_IN_SECONDS );

		return $data;
	}
}


if ( ! function_exists( 'bsfp_get_bitcoin_events' ) ) {
	/**
	 * Fetch BitCoin Events and Conferences from bitcoin.org
	 *
	 * @return array|bool false on failure or array on success
	 */
	function bsfp_get_bitcoin_events() {

		if ( ! class_exists( 'BS_Financial_Pack_Pro_Utilities' ) ) {

			require BS_Financial_Pack_Pro::dir_path( 'includes/class-bs-financial-pack-pro-utilities.php' );
		}

		if ( ! function_exists( 'str_get_html' ) ) {

			require BS_Financial_Pack_Pro::dir_path( 'includes/libs/simple_html_dom.php' );
		}

		if ( ! $response = BS_Financial_Pack_Pro_Utilities::request( 'https://bitcoin.org/en/events', array(), TRUE ) ) {

			return FALSE;
		}

		$extract_link_pattern = "'<\s*a\s.*?href\s*=\s*			# find <a href=
						([\"\'])?					    # find single or double quote
						(?(1) (.*?)\\1 | ([^\s\>]+))	# if quote found, match up to next matching
						.*? > (.*?) <\s*\/a\s*>
						'isx";

		$desc   = '';
		$dom    = str_get_html( $response );
		$events = array();

		foreach ( $dom->find( '.eventtable', 0 )->children as $event ) {

			if ( ! isset( $event->children[2] ) ||
			     ! isset( $event->children[1] ) ||
			     ! isset( $event->children[0] )
			) {

				continue;
			}

			$date     = $event->children[0]->innertext;
			$link     = $event->children[1]->innertext;
			$location = $event->children[2]->innertext;

			if ( ! preg_match( $extract_link_pattern, $link, $match ) ) {
				continue;
			}

			$url   = empty( $match[3] ) ? $match[2] : $match[3];
			$title = htmlspecialchars_decode( $match[4] );

			$events[] = compact( 'date', 'location', 'url', 'title', 'desc' );
		}

		return $events;
	}
}


if ( ! function_exists( 'bsfp_get_cryptovest_events' ) ) {
	/**
	 * Fetch Blockchain Events and Conferences from cryptovest.com
	 *
	 * @return array|bool false on failure or array on success
	 */
	function bsfp_get_cryptovest_events() {

		if ( ! class_exists( 'BS_Financial_Pack_Pro_Utilities' ) ) {

			require BS_Financial_Pack_Pro::dir_path( 'includes/class-bs-financial-pack-pro-utilities.php' );
		}

		if ( ! function_exists( 'str_get_html' ) ) {

			require BS_Financial_Pack_Pro::dir_path( 'includes/libs/simple_html_dom.php' );
		}

		if ( ! $response = BS_Financial_Pack_Pro_Utilities::request( 'https://cryptovest.com/events/', array(), TRUE ) ) {

			return FALSE;
		}

		$events = array();

		//
		$dom         = str_get_html( $response );
		$events_dom  = $dom->find( '#main-table-events tr' );
		$event_count = count( $events_dom );

		for ( $i = 0; $i < $event_count; $i += 2 ) {

			if ( ! isset( $events_dom[ $i ] ) ) {
				continue;
			}

			$event = $events_dom[ $i ];

			$event->children[1]->find( 'span', 0 )->outertext       = '';
			$event->children[2]->find( '.view-more', 0 )->outertext = '';

			$title    = trim( strip_tags( $event->children[0]->innertext ) );
			$date     = trim( strip_tags( $event->children[1]->innertext ) );
			$location = trim( strip_tags( $event->children[2]->innertext ) );
			$url      = '';
			$desc     = '';


			if ( isset( $events_dom[ $i + 1 ] ) ) {

				$desc = $events_dom[ $i + 1 ]->children[3]->find( '.description-text', 0 )->innertext;
				$url  = $events_dom[ $i + 1 ]->children[3]->find( '.visit-website', 0 )->href;
			}

			$events[] = compact( 'date', 'location', 'url', 'title', 'desc' );
		}

		return $events;
	}
}


if ( ! function_exists( 'bsfp_get_top_crypto_currency_list' ) ) {

	/**
	 * Get list of trending crypto currencies
	 *
	 * @return array|bool array on success
	 */
	function bsfp_get_top_cryptocurrency_list() {

		if ( $cache = get_transient( 'fp_top_crypto_currencies' ) ) {

			return $cache;
		}

		if ( ! class_exists( 'BS_Financial_Pack_Pro_Utilities' ) ) {

			require BS_Financial_Pack_Pro::dir_path( 'includes/class-bs-financial-pack-pro-utilities.php' );
		}

		if ( ! $response = BS_Financial_Pack_Pro_Utilities::request( 'https://api.coinmarketcap.com/v1/ticker/?start=0&limit=100', array() ) ) {

			return FALSE;
		}

		set_transient( 'fp_top_crypto_currencies', $response, WEEK_IN_SECONDS );

		return $response;
	}
}


if ( ! function_exists( 'bsfp_get_stock_market_top_gainers_list' ) ) {
	/**
	 * Get list of top gainers in us stock market
	 *
	 * @return array
	 */
	function bsfp_get_stock_market_top_gainers_list( $count = - 1 ) {

		$file_path = BS_Financial_Pack_Pro::dir_path( 'includes/data/top-market-caps.json' );
		$stocks    = json_decode( file_get_contents( $file_path ), TRUE );

		if ( $count ) {
			return array_slice( $stocks, 0, $count, TRUE );
		}

		return $stocks;
	}
}


if ( ! function_exists( 'bsfp_get_currencies_list' ) ) {

	/**
	 * Get list of physical currencies
	 *
	 * @return array|bool array on success
	 */
	function bsfp_get_currencies_list( $count = - 1 ) {

		$cache = get_transient( 'fp_physical_currencies' );

		if ( is_array( $cache ) ) {

			if ( $count ) {
				return array_slice( $cache, 0, $count, TRUE );
			}

			return $cache;
		}

		if ( ! class_exists( 'BS_Financial_Pack_Pro_Utilities' ) ) {

			/** @noinspection PhpIncludeInspection */
			require BS_Financial_Pack_Pro::dir_path( 'includes/class-bs-financial-pack-pro-utilities.php' );
		}

		if ( ! $response = BS_Financial_Pack_Pro_Utilities::request( 'http://core.betterstudio.com/api/currency/rates.json' ) ) {

			$response = BS_Financial_Pack_Pro_Utilities::request( 'http://core-cf.betterstudio.com/api/currency/rates.json' );
		}

		if ( ! $response ) {

			$response = get_option( 'fp_physical_currencies', array() );
			set_transient( 'fp_physical_currencies', $response, HOUR_IN_SECONDS / 2 );

			if ( $count ) {

				return array_slice( $response, 0, $count, TRUE );
			}

			return $response;
		}

		set_transient( 'fp_physical_currencies', $response, HOUR_IN_SECONDS );
		update_option( 'fp_physical_currencies', $response );

		if ( $count ) {
			return array_slice( $response, 0, $count, TRUE );
		}

		return $response;
	}
}


if ( ! function_exists( 'bsfp_get_cryptocurrencies_list' ) ) {
	/**
	 * Get list of all cryptocurrencies
	 *
	 * @param int $count
	 *
	 * @return array
	 */
	function bsfp_get_cryptocurrencies_list( $count = - 1 ) {

		$file_path = BS_Financial_Pack_Pro::dir_path( 'includes/data/all-cryptocurrencies.json' );
		$coins     = json_decode( file_get_contents( $file_path ), TRUE );

		if ( $count ) {
			return array_slice( $coins, 0, $count, TRUE );
		}

		return $coins;
	}
}
