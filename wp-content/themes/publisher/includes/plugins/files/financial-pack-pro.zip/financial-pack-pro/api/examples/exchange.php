<?php

$abspath = realpath( str_repeat( '../', 5 ) );

require $abspath . '/wp-load.php';

?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport"
	      content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Exchange</title>
</head>
<body>


<script>
    var fpc_loc = <?php echo json_encode( bsfp_prepare_crypto_currency_exchange_data() ) ?>;

    function currency_convert(value, from_currency, to_currency) {

        from_currency = from_currency.toUpperCase();
        to_currency = to_currency.toUpperCase();

        var base;

        if ('USD' !== from_currency) {

            if (fpc_loc.currencies && fpc_loc.currencies[from_currency]) {

                value = value * fpc_loc.currencies[from_currency];

            } else if (fpc_loc.rates && fpc_loc.rates[from_currency]) {

                value = value / fpc_loc.rates[from_currency];

            } else {

                return false;
            }
        }

        var result;

        if ('USD' !== to_currency) {

            if (fpc_loc.rates && fpc_loc.rates[to_currency]) {

                result = value * fpc_loc.rates[to_currency];
            } else if (fpc_loc.currencies && fpc_loc.currencies[to_currency]) {

                result = value / fpc_loc.currencies[to_currency];
            }

        }

        return result;
    }


    //        console.log('1 BitCoin == ' + currency_convert(1, 'btc', 'usd') + ' $');
    //    console.log('2 BitCoin == ' + currency_convert(2, 'btc', 'eur') + ' Euro');
    //    console.log('1 BitCoin == ' + currency_convert(1, 'btc', 'usd') + ' Euro');
    //        console.log('20 Dollar == ' + currency_convert(20, 'usd', 'eur') + ' Euro');
    console.log('20 Euro == ' + currency_convert(43595.5, 'eur', 'btc') + ' btc');
</script>

<script>

</script>

</body>
</html>