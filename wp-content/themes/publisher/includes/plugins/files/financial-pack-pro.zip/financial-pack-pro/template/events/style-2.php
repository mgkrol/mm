<?php
/**
 * Type 2.
 */

if ( empty( $events ) ) {

	printf( '<div class="bs-fp-error">%s</div>', __( 'Cannot fetch data from server.', 'better-studio' ) );

	return;
}

?>

<div class="bsfp-event-list bsfp-event-2">
	<table class='bs-fpe bs-fpe-2 bs-fpe-t2'>
		<thead>
		<tr>
			<td><?php bs_financial_pack_translation_echo( 'events_date' ) ?></td>
			<td><?php bs_financial_pack_translation_echo( 'events_subject' ) ?></td>
			<td><?php bs_financial_pack_translation_echo( 'events_location' ) ?></td>
		</tr>
		</thead>

		<tbody>
		<?php foreach ( $events as $item ) { ?>
			<tr>
				<td class="fpe-td-date">
					<span class="fpe-date"><?php echo $item['date']; ?></span>
				</td>
				<td class="fpe-td-subject">
				<span class="fpe-subject">
					<?php if ( ! empty( $item['url'] ) ){ ?>
					<a href="<?php echo esc_url( $item['url'] ); ?>" rel="nofollow" target="_blank">
					<?php } ?>

					<?php echo $item['title'] ?></span>

					<?php if ( ! empty( $item['url'] ) ) { ?>
						</a>
					<?php } ?>

				</td>
				<td class="fpe-td-location">
					<div class="fpe-location">
						<span class="fpe-icon-location bsfi-map-marker"></span>
						<span class="fpe-location-address"><?php echo $item['location'] ?></span>
					</div>
				</td>
			</tr>
		<?php } ?>
		</tbody>
	</table>
</div>