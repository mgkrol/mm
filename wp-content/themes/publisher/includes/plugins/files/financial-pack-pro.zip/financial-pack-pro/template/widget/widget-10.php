<?php
/**
 * Type 3 => Style 3
 *
 * @var $atts
 * @var $api
 */


$data = $api->get( array(
	'prices'          => array(),
	'changes_average' => array(),
	'logo'            => array(),
) );

if ( empty( $data ) ) {

	bsfp_print_error();

	return;
}

foreach ( $data as $symbol => $item ) {

	$currency   = $item['main_currency'];
	$title_attr = $symbol;
	$_check     = array(
		'currency'     => '',
		'stock-market' => '',
	);

	if ( isset( $_check[ $atts['data-type'] ] ) ) {
		$name       = $symbol;
		$title_attr = $item['name'];
	} else {
		$name = $item['name'];
	}

	?>
	<div class='bs-fp bs-fp-10 bs-fp-t3 bs-fp-s3'>
		<div class="bs-fp-inner bsfp-clearfix">
			<div class="fp-text">
				<?php if ( ! empty( $item['logo'] ) ) { ?>
					<div class="fp-logo">
						<img alt="<?php echo $title_attr; ?>" src="<?php echo $item['logo']; ?>">
					</div>
				<?php } ?>

				<div class="fp-name" title="<?php echo $title_attr; ?>"><?php echo $name; ?></div>
			</div>

			<div class="fp-text">
				<?php if ( isset( $item['prices'][ $currency ] ) ) { ?>
					<div class="fp-price"><?php echo bsfp_format_currency( $item['prices'][ $currency ], $currency ); ?></div>
				<?php } ?>

				<span class="fp-change-object fp-<?php echo $item['changes_average'][ $currency ]['state']; ?>">
					<?php if ( $arrow = bsfp_get_arrow_class( $item, $currency, 'style-1' ) ) {
						?>
						<span class="fp-arrow <?php echo $arrow; ?>"></span>
						<?php
					} ?>

					<?php if ( ! empty( $item['changes_average'][ $currency ] ) ) { ?>
						<span class="fp-changes fp-changes-percentage">(<?php
							echo bsfp_format_percentage( $item['changes_average'][ $currency ]['percentage'], 2 );
							?>)</span>
					<?php } ?>
				</span>
			</div>
		</div>
	</div>
<?php }
