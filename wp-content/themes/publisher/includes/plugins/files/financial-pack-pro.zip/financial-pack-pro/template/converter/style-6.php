<?php
/**
 * Type 1 => Style 6
 *
 * @var $atts
 */
?>
<div class='bs-fpc bs-fpc-6 bs-fpc-t1 bs-fpc-s5'>
	<form class="fpc-form bsfp-clearfix">

		<div class="fpc-input-section fpc-input-section-amount">
			<label class="fpc-label-input"><?php bs_financial_pack_translation_echo( 'convert_amount' ) ?></label>
			<div class="fpc-field">
				<input type="text" class="fpc-input fpc-convert-from" value="1">
			</div>
		</div>

		<div class="fpc-input-section fpc-input-section-from">
			<label class="fpc-label-input"><?php bs_financial_pack_translation_echo( 'convert_from' ) ?></label>
			<div class="fpc-field fpc-field-uni">
				<div class="fpc-select-field">
					<img class="fpc-crypto-icon fpc-from-currency-icon" src="<?php echo $atts['from_currency_logo'] ?>">
					<?php
					bsfp_dropdown_helper( $atts['from_currencies'], array(
						'attrs'    => array(
							'class' => 'fpc-input fpc-from-unit',
						),
						'selected' => $atts['from_currency']
					) )
					?>
					<span class="fpc-select-arrow bsfi-arrow2-s"></span>
				</div>
			</div>
		</div>

		<a class="fpc-switch-arrow fpc-switch-arrow bsfi-arrow-left-right" href="#switch"></a>

		<div class="fpc-input-section fpc-input-section-to fpc-to-currency-field">
			<label class="fpc-label-input"><?php bs_financial_pack_translation_echo( 'convert_to' ) ?></label>
			<div class="fpc-field fpc-field-uni fpc-to-currency-field">
				<div class="fpc-select-field">
					<img class="fpc-flag-icon fpc-to-currency-icon" src="<?php echo $atts['to_currency_logo'] ?>">
					<?php
					bsfp_dropdown_helper( $atts['to_currencies'], array(
						'attrs'    => array(
							'class' => 'fpc-input fpc-to-unit',
						),
						'selected' => $atts['to_currency']
					) )
					?>
					<span class="fpc-select-arrow bsfi-arrow2-s"></span>
				</div>
			</div>
		</div>

		<div class="fpc-input-section fpc-input-section-result">
			<div class="fpc-result">
				<div class="fpc-result-section">
					<span class="fpc-from-currency-label">
						<span class="value">1</span> <span
								class="unit bsf-currency-code"><?php echo $atts['from_currency'] ?></span>
					</span>
					<span class="fpc-to-currency-label">
						<span class="value"></span> <span
								class="unit bsf-currency-code"><?php echo $atts['to_currency'] ?></span>
					</span>
				</div>
			</div>
		</div>

	</form>
</div>
