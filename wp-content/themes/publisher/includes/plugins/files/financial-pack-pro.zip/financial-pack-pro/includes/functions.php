<?php

if ( ! function_exists( 'bsfp_api_instance' ) ) {

	/**
	 * Get fresh instance of the api
	 *
	 * @see   BS_Financial_API_Manager::$providers_list for api list
	 *
	 * @param string $api
	 * @param array  $currencies
	 * @param array  $options
	 *
	 * @since 1.0.0
	 * @return BS_Financial_Service_Base|bool false on failure or object on success
	 */
	function bsfp_api_instance( $api, $currencies = array(), $options = array() ) {

		if ( ! class_exists( 'BS_Financial_API_Manager' ) ) {

			/** @noinspection PhpIncludeInspection */
			require BS_Financial_Pack_Pro::dir_path( 'api/class-bs-financial-api-manager.php' );
		}

		$manager = BS_Financial_API_Manager::instance( $api, $currencies, $options );

		if ( $api = $manager->get_service() ) {

			$api->init( $currencies, $options );

			return $api;
		}

		return FALSE;
	}
}

if ( ! function_exists( 'bsfp_is_host_accessible' ) ) {

	/**
	 * Is given url accessible
	 *
	 * @param string $url
	 *
	 * @since 1.0.0
	 * @return bool true if it does
	 */
	function bsfp_is_host_accessible( $url ) {

		$request = wp_remote_get( $url, array( 'timeout' => bf_is_localhost() ? 10 : 2, 'sslverify' => FALSE ) );

		return $request && ! is_wp_error( $request ) && 200 === wp_remote_retrieve_response_code( $request );
	}
}


if ( ! function_exists( 'bsfp_format_currency' ) ) {
	/**
	 * Format currency
	 *
	 * @copyright betterstudio.com
	 *
	 * @param string $number
	 * @param string $currency
	 * @param bool   $show_unit
	 * @param string $country
	 *
	 * @since     1.0.0
	 * @return string
	 */
	function bsfp_format_currency( $number, $currency, $show_unit = TRUE, $country = '' ) {

		$file_path = BS_Financial_Pack_Pro::dir_path( 'includes/data/format-currency.json' );

		if ( ! $data = json_decode( file_get_contents( $file_path ), TRUE ) ) {
			return '';
		}

		if ( empty( $data[ $currency ] ) ) {
			return '';
		}

		$data = $data[ $currency ];

		if ( $country ) {

			$country = strtoupper( $country );

			if ( isset( $data[ $country ] ) ) {

				$data = $data[ $country ];

			} else {

				$data = array_shift( $data );
			}

		} else {

			$data = array_shift( $data );
		}

		$decimals      = isset( $data['decimal_digits'] ) ? $data['decimal_digits'] : 0;
		$dec_point     = isset( $data['separators'][1] ) ? $data['separators'][1] : '.';
		$thousands_sep = isset( $data['separators'][0] ) ? $data['separators'][0] : ',';
		//
		$formatted = number_format( $number, $decimals, $dec_point, $thousands_sep );

		if ( $show_unit ) {
			if ( isset( $data['position'] ) && 'after' === $data['position'] ) {

				$formatted .= ' ' . $data['currency_symbol'];

			} else {

				$formatted = $data['currency_symbol'] . $formatted;

			}
		}

		if ( ! empty( $data['numbers'] ) ) {

			$formatted = strtr( $formatted, $data['numbers'] );
		}

		return $formatted;
	}
}


if ( ! function_exists( 'bsfp_format_percentage' ) ) {

	/**
	 * Formats Percentage value
	 *
	 * @param float $value
	 * @param int   $round
	 * @param bool  $show_percentage
	 * @param bool  $show_symbol
	 *
	 * @since 1.0.0
	 * @return string
	 */
	function bsfp_format_percentage( $value, $round = 2, $show_percentage = TRUE, $show_symbol = TRUE ) {

		$value = round( $value, $round );

		if ( $show_symbol ) {

			if ( $value > 0 ) {
				$value = '+' . $value;
			}
		} else {
			if ( $value < 0 ) {
				$value *= - 1;
			}
		}

		if ( $show_percentage ) {
			$value .= '%';
		}

		return $value;
	}
}


if ( ! function_exists( 'bsfp_plot_time_data' ) ) {

	/**
	 * Prepare data for chart view
	 *
	 * @param array $plot_data
	 *
	 * @since 1.0.0
	 * @return array
	 */
	function bsfp_plot_time_data( array $plot_data ) {

		ksort( $plot_data );
		$min = key( $plot_data );
		//
		end( $plot_data );
		$max = key( $plot_data );

		$diff = absint( $max - $min );

		if ( $diff < HOUR_IN_SECONDS ) {

			// $since = round( $diff / MINUTE_IN_SECONDS );
			// $since = max( 1, $since );
			//
			$format = 'i:s';


		} elseif ( $diff < DAY_IN_SECONDS && $diff >= HOUR_IN_SECONDS ) {

			// $since = round( $diff / HOUR_IN_SECONDS );
			// $since = max( 1, $since );
			//
			$format = 'H:i';

		} elseif ( $diff < WEEK_IN_SECONDS && $diff >= DAY_IN_SECONDS ) {

			// $since = round( $diff / DAY_IN_SECONDS );
			// $since = max( 1, $since );
			//
			$format = 'F d';

		} elseif ( $diff < MONTH_IN_SECONDS && $diff >= WEEK_IN_SECONDS ) {

			// $since = round( $diff / WEEK_IN_SECONDS );
			// $since = max( 1, $since );
			//
			$format = 'm/d';

		} elseif ( $diff < YEAR_IN_SECONDS && $diff >= MONTH_IN_SECONDS ) {

			// $since = round( $diff / MONTH_IN_SECONDS );
			// $since = max( 1, $since );
			//
			$format = 'Y-m-d';

		} elseif ( $diff >= YEAR_IN_SECONDS ) {

			// $since = round( $diff / YEAR_IN_SECONDS );
			// $since = max( 1, $since );

			$format = 'Y/m';
		}


		$series = array();
		$labels = array();

		foreach ( $plot_data as $time => $value ) {

			$labels[] = date( $format, $time );
			$series[] = $value;
		}

		$series = array( $series );

		return compact( 'series', 'labels' );
	}
}

if ( ! function_exists( 'bsfp_translation_get' ) ) {

	/**
	 * Get panel translation string
	 *
	 * @param string $option_key
	 *
	 * @since 1.0.0
	 * @return string
	 */
	function bsfp_translation_get( $option_key ) {

		return bf_get_option( $option_key, 'bs_financial_pack' );
	}
}

if ( ! function_exists( 'bs_financial_pack_translation_echo' ) ) {

	/**
	 * Print panel translation string
	 *
	 * @param string $option_key
	 *
	 * @since 1.0.0
	 */
	function bs_financial_pack_translation_echo( $option_key ) {

		echo bsfp_translation_get( $option_key );
	}
}


if ( ! function_exists( 'bsfp_cryptocurrencies_select_callback' ) ) {

	/**
	 * Used to retrieving Tags from an keyword
	 *
	 * @param string $keyword
	 * @param array  $exclude
	 *
	 * @since 1.0.0
	 * @return array
	 */
	function bsfp_cryptocurrencies_select_callback( $keyword, $exclude ) {

		$keyword = strtolower( $keyword );
		$results = array();
		$exclude = explode( ',', $exclude );
		$coins   = bsfp_get_cryptocurrencies_list();
		$count   = 0;

		foreach ( $coins as $key => $value ) {

			if ( $count >= 20 ) {
				break;
			}

			if ( strstr( strtolower( $value['search'] ), $keyword ) && ! in_array( $key, $exclude ) ) {
				$results[ $key ] = $value['name'];
				$count ++;
			}
		}

		return $results;
	}
}


if ( ! function_exists( 'bsfp_cryptocurrencies_select_callback_name' ) ) {

	/**
	 * Used for finding Category Name from ID
	 *
	 * @param string $id
	 *
	 * @since 1.0.0
	 * @return string|void string on success or null on failure.
	 */
	function bsfp_cryptocurrencies_select_callback_name( $id ) {

		$coins = bsfp_get_cryptocurrencies_list();

		if ( isset( $coins[ $id ] ) ) {
			return $coins[ $id ]['name'];
		}
	}
}


if ( ! function_exists( 'bsfp_currencies_select_callback' ) ) {

	/**
	 * Used to retrieving Tags from an keyword
	 *
	 * @param string $keyword
	 * @param array  $exclude
	 *
	 * @since 1.0.0
	 * @return array
	 */
	function bsfp_currencies_select_callback( $keyword, $exclude ) {

		$keyword = strtolower( $keyword );
		$results = array();
		$exclude = explode( ',', $exclude );
		$coins   = bsfp_get_currencies_list();
		$count   = 0;

		foreach ( $coins as $key => $value ) {

			if ( $count >= 20 ) {
				break;
			}

			if ( ( strstr( strtolower( $key ), $keyword ) || strstr( strtolower( $value['name'] ), $keyword ) ) && ! in_array( $key, $exclude ) ) {
				$results[ $key ] = $value['name'];
				$count ++;
			}
		}

		return $results;
	}
}


if ( ! function_exists( 'bsfp_currencies_select_callback_name' ) ) {

	/**
	 * Used for finding Category Name from ID
	 *
	 * @param string $id
	 *
	 * @since 1.0.0
	 * @return string|void string on success or null on failure.
	 */
	function bsfp_currencies_select_callback_name( $id ) {

		$coins = bsfp_get_currencies_list();

		if ( isset( $coins[ $id ] ) ) {
			return $coins[ $id ]['name'];
		}
	}
}


if ( ! function_exists( 'bsfp_stock_market_select_callback' ) ) {

	/**
	 * Used to retrieving Tags from an keyword
	 *
	 * @param string $keyword
	 * @param array  $exclude
	 *
	 * @since 1.0.0
	 * @return array
	 */
	function bsfp_stock_market_select_callback( $keyword, $exclude ) {

		$keyword = strtolower( $keyword );
		$results = array();
		$exclude = explode( ',', $exclude );
		$coins   = bsfp_get_stock_market_top_gainers_list();
		$count   = 0;

		foreach ( $coins as $key => $value ) {

			if ( $count >= 20 ) {
				break;
			}

			if ( ( strstr( strtolower( $value['name'] ), $keyword ) || strstr( strtolower( $value['code'] ), $keyword ) ) && ! in_array( $key, $exclude ) ) {
				$results[ $key ] = $value['name'];
				$count ++;
			}
		}

		return $results;
	}
}


if ( ! function_exists( 'bsfp_stock_market_select_callback_name' ) ) {

	/**
	 * Used for stock market name from ID
	 *
	 * @param string $id
	 *
	 * @since 1.0.0
	 * @return string|void string on success or null on failure.
	 */
	function bsfp_stock_market_select_callback_name( $id ) {

		$coins = bsfp_get_stock_market_top_gainers_list();

		if ( isset( $coins[ $id ] ) ) {
			return $coins[ $id ]['name'];
		}
	}
}


if ( ! function_exists( 'bsfp_get_currencies_list_option' ) ) {

	/**
	 * Get list of all currencies
	 *
	 * @since 1.0.0
	 * @return array
	 */
	function bsfp_get_currencies_list_option() {

		$options = array();

		foreach ( bsfp_get_currencies_list() as $key => $value ) {
			$options[ $key ] = $value['name'];
		}

		return $options;
	}
}


if ( ! function_exists( 'bsfp_get_cryptocurrencies_list_option' ) ) {

	/**
	 * Get list of all crypto currencies
	 *
	 * @since 1.0.0
	 * @return array
	 */
	function bsfp_get_cryptocurrencies_list_option() {

		$options = array();

		foreach ( bsfp_get_cryptocurrencies_list() as $key => $value ) {
			$options[ $key ] = $value['name'];
		}

		return $options;
	}
}


if ( ! function_exists( 'bsfp_cryptocurrency_widget_styles_option' ) ) {

	/**
	 * List of cryptocurrency widget styles used as BF field callback
	 *
	 * @since 1.0.0
	 * @return array
	 */
	function bsfp_cryptocurrency_widget_styles_option() {

		$version = BS_Financial_Pack_Pro::$version;

		$option = array();

		$option['widget-1']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-1.png?v=' . $version ),
			'label' => __( 'Style 1', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-2']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-2.png?v=' . $version ),
			'label' => __( 'Style 2', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-3']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-3.png?v=' . $version ),
			'label' => __( 'Style 3', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-4']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-4.png?v=' . $version ),
			'label' => __( 'Style 4', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-5']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-5.png?v=' . $version ),
			'label' => __( 'Style 5', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-6']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-6.png?v=' . $version ),
			'label' => __( 'Style 6', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-7']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-7.png?v=' . $version ),
			'label' => __( 'Style 7', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-8']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-8.png?v=' . $version ),
			'label' => __( 'Style 8', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-9']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-9.png?v=' . $version ),
			'label' => __( 'Style 9', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-10'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-10.png?v=' . $version ),
			'label' => __( 'Style 10', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-11'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-11.png?v=' . $version ),
			'label' => __( 'Style 11', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-12'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-12.png?v=' . $version ),
			'label' => __( 'Style 12', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-13'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-13.png?v=' . $version ),
			'label' => __( 'Style 13', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-14'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-14.png?v=' . $version ),
			'label' => __( 'Style 14', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-15'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-15.png?v=' . $version ),
			'label' => __( 'Style 15', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-16'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-16.png?v=' . $version ),
			'label' => __( 'Style 16', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
					__( 'With Chart', 'better-studio' ),
				),
			),
		);
		$option['widget-17'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-17.png?v=' . $version ),
			'label' => __( 'Style 17', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
					__( 'With Chart', 'better-studio' ),
				),
			),
		);
		$option['widget-18'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-18.png?v=' . $version ),
			'label' => __( 'Style 18', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
					__( 'With Chart', 'better-studio' ),
				),
			),
		);
		$option['widget-19'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-19.png?v=' . $version ),
			'label' => __( 'Style 19', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
					__( 'With Chart', 'better-studio' ),
				),
			),
		);
		$option['widget-20'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-20.png?v=' . $version ),
			'label' => __( 'Style 20', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-21'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-21.png?v=' . $version ),
			'label' => __( 'Style 21', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-22'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-22.png?v=' . $version ),
			'label' => __( 'Style 22', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-23'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-23.png?v=' . $version ),
			'label' => __( 'Style 23', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-24'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-24.png?v=' . $version ),
			'label' => __( 'Style 24', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-25'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-25.png?v=' . $version ),
			'label' => __( 'Style 25', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
					__( 'With Chart', 'better-studio' ),
				),
			),
		);
		$option['widget-26'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-26.png?v=' . $version ),
			'label' => __( 'Style 26', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-27'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-shortcode-style-27.png?v=' . $version ),
			'label' => __( 'Style 27', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Chart', 'better-studio' ),
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);

		return $option;
	} //bsfp_cryptocurrency_widget_styles_option
}


if ( ! function_exists( 'bsfp_stockmarket_widget_styles_option' ) ) {
	/**
	 * List of stock market widget styles used as BF field callback
	 *
	 * @since 1.0.0
	 * @return array
	 */
	function bsfp_stockmarket_widget_styles_option() {

		$version = BS_Financial_Pack_Pro::$version;

		$option = array();

		$option['widget-1']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-1.png?v=' . $version ),
			'label' => __( 'Style 1', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-2']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-2.png?v=' . $version ),
			'label' => __( 'Style 2', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-3']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-3.png?v=' . $version ),
			'label' => __( 'Style 3', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-4']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-4.png?v=' . $version ),
			'label' => __( 'Style 4', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-5']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-5.png?v=' . $version ),
			'label' => __( 'Style 5', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-6']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-6.png?v=' . $version ),
			'label' => __( 'Style 6', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-7']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-7.png?v=' . $version ),
			'label' => __( 'Style 7', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-8']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-8.png?v=' . $version ),
			'label' => __( 'Style 8', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-9']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-9.png?v=' . $version ),
			'label' => __( 'Style 9', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-10'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-10.png?v=' . $version ),
			'label' => __( 'Style 10', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-11'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-11.png?v=' . $version ),
			'label' => __( 'Style 11', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-12'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-12.png?v=' . $version ),
			'label' => __( 'Style 12', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-13'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-13.png?v=' . $version ),
			'label' => __( 'Style 13', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
					__( 'Multi Currency', 'better-studio' ),
				),
			),
		);
		$option['widget-14'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-14.png?v=' . $version ),
			'label' => __( 'Style 14', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-15'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-15.png?v=' . $version ),
			'label' => __( 'Style 15', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-16'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-16.png?v=' . $version ),
			'label' => __( 'Style 16', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
					__( 'With Chart', 'better-studio' ),
				),
			),
		);
		$option['widget-17'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-17.png?v=' . $version ),
			'label' => __( 'Style 17', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
					__( 'With Chart', 'better-studio' ),
				),
			),
		);
		$option['widget-18'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-18.png?v=' . $version ),
			'label' => __( 'Style 18', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
					__( 'With Chart', 'better-studio' ),
				),
			),
		);
		$option['widget-19'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-19.png?v=' . $version ),
			'label' => __( 'Style 19', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
					__( 'With Chart', 'better-studio' ),
				),
			),
		);
		$option['widget-20'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-20.png?v=' . $version ),
			'label' => __( 'Style 20', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-21'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-21.png?v=' . $version ),
			'label' => __( 'Style 21', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-22'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-22.png?v=' . $version ),
			'label' => __( 'Style 22', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-23'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-23.png?v=' . $version ),
			'label' => __( 'Style 23', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
					__( 'Multi Currency', 'better-studio' ),
				),
			),
		);
		$option['widget-24'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-24.png?v=' . $version ),
			'label' => __( 'Style 24', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-25'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-25.png?v=' . $version ),
			'label' => __( 'Style 25', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
					__( 'With Chart', 'better-studio' ),
				),
			),
		);
		$option['widget-26'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-26.png?v=' . $version ),
			'label' => __( 'Style 26', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['widget-27'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-shortcode-style-27.png?v=' . $version ),
			'label' => __( 'Style 27', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Chart', 'better-studio' ),
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);

		return $option;
	} //bsfp_stockmarket_widget_styles_option
}


if ( ! function_exists( 'bsfp_currency_widget_styles_option' ) ) {
	/**
	 * List of currency widget styles used as BF field callback
	 *
	 * @since 1.0.0
	 * @return array
	 */
	function bsfp_currency_widget_styles_option() {

		$version = BS_Financial_Pack_Pro::$version;

		$option = array();

		$option['widget-1']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-1.png?v=' . $version ),
			'label' => __( 'Style 1', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-2']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-2.png?v=' . $version ),
			'label' => __( 'Style 2', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-3']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-3.png?v=' . $version ),
			'label' => __( 'Style 3', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-4']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-4.png?v=' . $version ),
			'label' => __( 'Style 4', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-5']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-5.png?v=' . $version ),
			'label' => __( 'Style 5', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-6']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-6.png?v=' . $version ),
			'label' => __( 'Style 6', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-7']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-7.png?v=' . $version ),
			'label' => __( 'Style 7', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-8']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-8.png?v=' . $version ),
			'label' => __( 'Style 8', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-9']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-9.png?v=' . $version ),
			'label' => __( 'Style 9', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-10'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-10.png?v=' . $version ),
			'label' => __( 'Style 10', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-11'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-11.png?v=' . $version ),
			'label' => __( 'Style 11', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-12'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-12.png?v=' . $version ),
			'label' => __( 'Style 12', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-13'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-13.png?v=' . $version ),
			'label' => __( 'Style 13', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
					__( 'Multi Currency', 'better-studio' ),
				),
			),
		);
		$option['widget-14'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-14.png?v=' . $version ),
			'label' => __( 'Style 14', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-15'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-15.png?v=' . $version ),
			'label' => __( 'Style 15', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-16'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-16.png?v=' . $version ),
			'label' => __( 'Style 16', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
					__( 'With Chart', 'better-studio' ),
				),
			),
		);
		$option['widget-17'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-17.png?v=' . $version ),
			'label' => __( 'Style 17', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
					__( 'With Chart', 'better-studio' ),
				),
			),
		);
		$option['widget-18'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-18.png?v=' . $version ),
			'label' => __( 'Style 18', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Flag', 'better-studio' ),
					__( 'With Chart', 'better-studio' ),
				),
			),
		);
		$option['widget-19'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-19.png?v=' . $version ),
			'label' => __( 'Style 19', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Flag', 'better-studio' ),
					__( 'With Chart', 'better-studio' ),
				),
			),
		);
		$option['widget-20'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-20.png?v=' . $version ),
			'label' => __( 'Style 20', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-21'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-21.png?v=' . $version ),
			'label' => __( 'Style 21', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-22'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-22.png?v=' . $version ),
			'label' => __( 'Style 22', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-23'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-23.png?v=' . $version ),
			'label' => __( 'Style 23', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Flag', 'better-studio' ),
					__( 'Multi Currency', 'better-studio' ),
				),
			),
		);
		$option['widget-24'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-24.png?v=' . $version ),
			'label' => __( 'Style 24', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-25'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-25.png?v=' . $version ),
			'label' => __( 'Style 25', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
					__( 'With Chart', 'better-studio' ),
				),
			),
		);
		$option['widget-26'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-26.png?v=' . $version ),
			'label' => __( 'Style 26', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['widget-27'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/currency-shortcode-style-27.png?v=' . $version ),
			'label' => __( 'Style 27', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Chart', 'better-studio' ),
					__( 'Without Flag', 'better-studio' ),
				),
			),
		);

		return $option;
	} //bsfp_currency_widget_styles_option
}


if ( ! function_exists( 'bsfp_cryptocurrency_table_styles_option' ) ) {
	/**
	 * Crypto currency table widget styles
	 *
	 * @since 1.0.0
	 * @return array
	 */
	function bsfp_cryptocurrency_table_styles_option() {

		$version = BS_Financial_Pack_Pro::$version;

		$option = array();

		$option['style-1'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-table-style-1.png?v=' . $version ),
			'label' => __( 'Style 1', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Chart', 'better-studio' ),
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['style-2'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-table-style-2.png?v=' . $version ),
			'label' => __( 'Style 2', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Chart', 'better-studio' ),
					__( 'With Flag', 'better-studio' ),
				),
			),
		);
		$option['style-3'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-table-style-3.png?v=' . $version ),
			'label' => __( 'Style 3', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Flag', 'better-studio' ),
				),
			),
		);
		$option['style-4'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-table-style-4.png?v=' . $version ),
			'label' => __( 'Style 4', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Flag', 'better-studio' ),
				),
			),
		);
		$option['style-5'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-table-style-5.png?v=' . $version ),
			'label' => __( 'Style 5', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Flag', 'better-studio' ),
				),
			),
		);

		return $option;
	} //bsfp_cryptocurrency_table_styles_option
}


if ( ! function_exists( 'bsfp_widgets_style_align_option' ) ) {
	/**
	 * List of widgets align styles
	 *
	 * @since 1.0.0
	 * @return array
	 */
	function bsfp_widgets_style_align_option() {

		$version = BS_Financial_Pack_Pro::$version;

		$option = array();

		$option['auto']     = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/items-align-auto.png?v=' . $version ),
			'label' => __( 'Auto Align', 'better-studio' ),
		);
		$option['columned'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/items-align-columned.png?v=' . $version ),
			'label' => __( 'Columned Style', 'better-studio' ),
		);
		$option['marquee']  = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/items-align-marquee.gif?v=' . $version ),
			'label' => __( 'Marquee', 'better-studio' ),
		);

		return $option;
	} // bsfp_widgets_style_align_option
}


if ( ! function_exists( 'bsfp_get_arrow_class' ) ) {
	/**
	 * Generate arrow class based of style and data
	 *
	 * @param array  $item
	 * @param string $currency
	 * @param string $style
	 *
	 * @since 1.0.0
	 * @return bool|string
	 */
	function bsfp_get_arrow_class( $item, $currency = 'USD', $style = 'style-1' ) {

		if ( empty( $item['changes_average'][ $currency ]['state'] ) ) {
			return FALSE;
		}

		$_check = array(
			'style-1' => array(
				'up'    => 'arrow-n',
				'down'  => 'arrow-s',
				'fixed' => 'arrow-e',
			),
			'style-2' => array(
				'up'    => 'arrow-ne',
				'down'  => 'arrow-se',
				'fixed' => 'arrow-e',
			),
			'style-3' => array(
				'up'    => 'arrow3-n',
				'down'  => 'arrow3-s',
				'fixed' => 'arrow3-e',
			),
			'style-4' => array(
				'up'    => 'arrow2-n',
				'down'  => 'arrow2-s',
				'fixed' => 'arrow2-e',
			),
		);

		if ( ! isset( $_check[ $style ][ $item['changes_average'][ $currency ]['state'] ] ) ) {
			return FALSE;
		}

		return "bsfi-{$_check[$style][$item['changes_average'][$currency]['state']]}";
	}
}


if ( ! function_exists( 'bsfp_cryptocurrency_events_styles_option' ) ) {
	/**
	 * List of cryptocurrency event widget styles used as BF field callback
	 *
	 * @since 1.0.0
	 * @return array
	 */
	function bsfp_cryptocurrency_events_styles_option() {

		$version = BS_Financial_Pack_Pro::$version;

		$option = array();

		$option['style-1'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-events-style-1.png?v=' . $version ),
			'label' => __( 'Style 1', 'better-studio' ),
		);
		$option['style-2'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-events-style-2.png?v=' . $version ),
			'label' => __( 'Style 2', 'better-studio' ),
		);

		return $option;
	} //bsfp_cryptocurrency_events_styles_option
}


if ( ! function_exists( 'bsfp_dropdown_helper' ) ) {
	/**
	 * Helper function to generate <select> dropdown list for choices
	 *
	 * @param array $choices
	 * @param array $options
	 *
	 * @since 1.0.0
	 * @return string
	 */
	function bsfp_dropdown_helper( array $choices, array $options = array() ) {

		$options = bf_merge_args( $options, array(
			'attrs'    => array(),
			'selected' => array(),
			'echo'     => TRUE,
		) );

		if ( ! $options['echo'] ) {
			ob_start();
		}

		//
		// Attrs
		//
		{
			$attr = '';
			foreach ( $options['attrs'] as $key => $value ) {
				$attr .= " {$key}='{$value}'";
			}
		}

		?>
		<select<?php echo $attr; ?>>
			<?php
			foreach ( $choices as $key => $value ) {

				echo "\t\t";
				printf(
					'<option value="%s"%s>%s</option>',
					$key, selected( $options['selected'], $key, FALSE ), $value
				);
				echo "\n";
			}
			?>
		</select>
		<?php

		if ( ! $options['echo'] ) {
			return ob_get_clean();
		}
	}
}


if ( ! function_exists( 'bsfp_load_view' ) ) {


	/**
	 * Load view file
	 *
	 * @param string $view_file view file path
	 * @param array  $vars      pass variables to view
	 * @param array  $options   options
	 *
	 * @return string|WP_Error string on success or WP_Error on failure.
	 */
	function bsfp_load_view( $view_file, $vars = array(), $options = array() ) {

		$options = bf_merge_args( $options, array(
			'root' => BS_Financial_Pack_Pro::dir_path( '/template/' ),
			'echo' => TRUE,
		) );

		try {

			if ( ! is_string( $view_file ) ) {
				throw new BF_Exception( 'Invalid file name passed!', 'invalid_file_name' );
			}

			$view_full_path = trailingslashit( $options['root'] ) . trim( $view_file, '/' ) . '.php';

			if ( ! is_readable( $view_full_path ) ) {
				throw new BF_Exception( "Cannot read the view file $view_file", 'file_not_found' );
			}


			if ( ! $options['echo'] ) {
				ob_start();
			}

			extract( $vars );

			include $view_full_path;

			if ( ! $options['echo'] ) {
				return ob_get_clean();
			}

		} catch( BF_Exception $e ) {

			return new WP_Error( $e->getCode(), $e->getMessage() );
		}
	}
}


if ( ! function_exists( 'bsfp_stockmarket_table_styles_option' ) ) {
	/**
	 * List of stockmarket table widget styles used as BF field callback
	 *
	 * @return array
	 */
	function bsfp_stockmarket_table_styles_option() {

		$version = BS_Financial_Pack_Pro::$version;

		$option = array();

		$option['style-1'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-table-style-1.png?v=' . $version ),
			'label' => __( 'Style 1', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Chart', 'better-studio' ),
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['style-2'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-table-style-2.png?v=' . $version ),
			'label' => __( 'Style 2', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'With Chart', 'better-studio' ),
					__( 'With Logo', 'better-studio' ),
				),
			),
		);
		$option['style-3'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-table-style-3.png?v=' . $version ),
			'label' => __( 'Style 3', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['style-4'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-table-style-4.png?v=' . $version ),
			'label' => __( 'Style 4', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);
		$option['style-5'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/stock-table-style-5.png?v=' . $version ),
			'label' => __( 'Style 5', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'Without Logo', 'better-studio' ),
				),
			),
		);

		return $option;
	} //bsfp_stockmarket_table_styles_option
}


if ( ! function_exists( 'bsfp_currency_converter_styles_option' ) ) {
	/**
	 * List of currency convertor widget styles used as BF field callback
	 *
	 * @return array
	 */
	function bsfp_currency_converter_styles_option() {

		$version = BS_Financial_Pack_Pro::$version;

		$option = array();

		$option['style-1'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-converter-style-1.png?v=' . $version ),
			'label' => __( 'Style 1', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'in Column', 'better-studio' ),
				),
			),
		);
		$option['style-2'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-converter-style-2.png?v=' . $version ),
			'label' => __( 'Style 2', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'in Column', 'better-studio' ),
				),
			),
		);
		$option['style-3'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-converter-style-3.png?v=' . $version ),
			'label' => __( 'Style 3', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'in Column', 'better-studio' ),
				),
			),
		);
		$option['style-4'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-converter-style-4.png?v=' . $version ),
			'label' => __( 'Style 4', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'in Column', 'better-studio' ),
				),
			),
		);
		$option['style-5'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-converter-style-5.png?v=' . $version ),
			'label' => __( 'Style 5', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'in Row', 'better-studio' ),
				),
			),
		);
		$option['style-6'] = array(
			'img'   => BS_Financial_Pack_Pro::dir_url( 'img/admin/crypto-converter-style-5.png?v=' . $version ),
			'label' => __( 'Style 6', 'better-studio' ),
			'info'  => array(
				'cat' => array(
					__( 'in Row', 'better-studio' ),
				),
			),
		);

		return $option;
	} //bsfp_currency_converter_styles_option
}


if ( ! function_exists( 'bsfp_print_error' ) ) {
	/**
	 * Handy function for printing the errors
	 *
	 * @param string $message
	 * @param string $type
	 */
	function bsfp_print_error( $message = '', $type = 'data-fetch' ) {

		if ( empty( $message ) ) {
			if ( $type === 'data-fetch' ) {
				$message = __( 'Cannot fetch data from server.', 'better-studio' );
			}
		}

		echo "<div class='bs-fp-error bs-fp-error-{$type}'>{$message}</div>";
	}
}
