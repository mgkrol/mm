<?php
/**
 * Type 2 => Style 1
 *
 * @var $atts
 * @var $api
 */

$data = $api->get( array(
	'prices'          => array(),
	'changes_average' => array(),
	'logo'            => array(),
) );

if ( empty( $data ) ) {

	bsfp_print_error();

	return;
}

foreach ( $data as $symbol => $item ) {

	$currency   = $item['main_currency'];
	$title_attr = $symbol;
	$_check     = array(
		'currency'     => '',
		'stock-market' => '',
	);

	if ( isset( $_check[ $atts['data-type'] ] ) ) {
		$name   = $symbol;
		$symbol = $item['name'];
	} else {
		$name = $item['name'];
	}

	?>
	<div class='bs-fp bs-fp-6 bs-fp-t2 bs-fp-s1'>
		<div class="bs-fp-inner bsfp-clearfix">
			<?php if ( ! empty( $item['logo'] ) ) { ?>
				<div class="fp-logo">
					<img alt="<?php echo $title_attr; ?>" src="<?php echo $item['logo']; ?>">
				</div>
			<?php } ?>

			<div class="fp-text">
				<div class="fp-name" title="<?php echo $title_attr; ?>"><?php echo $name; ?></div>

				<?php if ( isset( $item['prices'][ $currency ] ) ) { ?>
					<div class="fp-price"><?php echo bsfp_format_currency( $item['prices'][ $currency ], $currency ); ?></div>
				<?php } ?>

				<?php if ( ! empty( $item['changes_average'][ $currency ] ) ) { ?>
					<div class="fp-changes fp-changes-point fp-<?php echo $item['changes_average'][ $currency ]['state']; ?>">
						<?php echo bsfp_format_percentage( $item['changes_average'][ $currency ]['value'], 2, FALSE ); ?>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
<?php }
