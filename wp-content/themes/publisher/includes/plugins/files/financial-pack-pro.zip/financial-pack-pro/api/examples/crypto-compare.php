<?php


$abspath = realpath( str_repeat( '../', 5 ) );

require $abspath . '/wp-load.php';

/**
 * @var BS_Financial_Crypto_Service $api
 */
$api = bsfp_api_instance( 'crypto_compare' );

if ( ! $api ) {
	die( "<h1>Error :-/  cannot connect to cryptocompare</h1>" );
}

$api->set_coins( array( 'btc' ) );
$api->set_currencies( array( 'USD', 'IRR', 'GBP', 'EUR' ) );


$results = $api->get( array(
	'daily_history'          => array(), // arguments
	'hourly_history'         => array(),
	'changes_average'        => array(),
	'changes_average_single' => array(),
	'statistics'             => array(),
	'logo'                   => array(),
	'prices'                 => array(),
) );

bf_var_dump_exit( $results );


//$hour_history = $api->hourly_history( strtotime( '-1 day' ), time() );
$changes    = $api->changes_average();
$statistics = $api->statistics();
$logo_list  = $api->logo_list();
$prices     = $api->prices();

?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport"
	      content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Financial Pack</title>

	<link href="http://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">

	<link rel="stylesheet" href="http://cdn.jsdelivr.net/chartist.js/latest/chartist.min.css">
	<script src="http://cdn.jsdelivr.net/chartist.js/latest/chartist.min.js"></script>

</head>
<body>

<style>
	.fa-arrow-up {
		color: green;
	}

	.fa-arrow-down {
		color: red;
	}

	.logo {
		vertical-align: middle;
		margin-right: 10px;
	}
</style>


<div>

	<h2>Overview</h2>

	<?php

	foreach ( $prices as $currency => $amount ) :

		$change_percentage = isset( $changes[ $currency ]['USD']['percentage'] ) ?
			$changes[ $currency ]['USD']['percentage'] : 0;

		$change_value = isset( $changes[ $currency ]['USD']['value'] ) ?
			$changes[ $currency ]['USD']['value'] : 1;
		?>
		<ul>
			<li>

				<img src="<?php echo isset( $logo_list[ $currency ] ) ? $logo_list[ $currency ] : '' ?>"
				     alt="<?php echo $currency ?> " width="32" class="logo">

				<strong><?php echo $currency ?></strong>

				<?php echo bsfp_format_currency( $amount['USD'], 'usd' ); ?>
				<?php

				if ( $change_percentage > 0 ) {

					echo '<i class="fa fa-arrow-up"></i>';

				} elseif ( $change_percentage < 0 ) {

					echo '<i class="fa fa-arrow-down"></i>';
				}

				echo "($change_percentage%)"
				?>
			</li>
		</ul>

	<?php endforeach ?>

</div>

<hr>

<div class="visualization">
	<h2>Plot Chart</h2>
	<div class="ct-chart"></div>
</div>


<hr>

<div class="statistics">

	<h2>statistics</h2>

	<h4>BitCoin Supply: Ƀ <?php echo number_format( $statistics['BTC']['USD']['supply'] ) ?></h4>

	<h4>BitCoin MarketCap: $ <?php echo number_format( $statistics['BTC']['USD']['market_cap'] ) ?> </h4>

</div>

<hr>


<script>

    new Chartist.Line('.ct-chart', <?php echo json_encode( bsfp_plot_time_data( $hour_history['BTC']['USD'] ) ) ?> , {
        showArea: true,
    });
</script>
</body>
</html>