<?php


abstract class BS_Financial_Crypto_Service extends BS_Financial_Service_Base {

	public function set_coins( array $coins ) {

		parent::set_items( $coins );
	}


	/**
	 * @param float $changed_value
	 * @param float $changed_percentage
	 *
	 * @return array
	 * @throws Exception
	 */
	protected function format_changes( $changed_value, $changed_percentage ) {

		$rates   = bsfp_get_exchange_rate( $this->get_currencies(), $this->base_currency );
		$results = array();

		foreach ( $rates as $currency => $rate ) {

			$results[ $currency ]['percentage'] = $changed_percentage;
			$results[ $currency ]['value']      = $changed_value * $rate;
			$results[ $currency ]['state']      = $changed_percentage > 0 ? 'up' : 'down';
		}

		return $results;

	}


	/**
	 * @param array $stat
	 *
	 * @return array
	 * @throws Exception
	 */
	protected function format_statistics( $stat ) {

		$rates   = bsfp_get_exchange_rate( $this->get_currencies(), $this->base_currency );
		$results = array();

		foreach ( $rates as $currency => $rate ) {

			if ( isset( $stat['supply'] ) ) {
				$results[ $currency ]['supply'] = $stat['supply'];
			}

			$results[ $currency ]['market_cap'] = $stat['market_cap'] * $rate;
		}

		return $results;
	}

	//
	// Exchange methods
	//

	/**
	 * Convert amount of digital currencies list cash
	 *
	 * @param array $digital_list
	 *
	 * @return array|bool false on failure.
	 */
	public function exchange_to_cash( array $digital_list ) {

		$digital_list = array_map( 'strtoupper', $digital_list );

		if ( ! $prices = $this->prices() ) {
			return FALSE;
		}

		$converted = array();

		foreach ( $digital_list as $currency => $value ) {

			if ( ! isset( $prices[ $currency ] ) ) {
				continue;
			}

			$converted[ $currency ] = $this->_exchange_to_cash_single( $prices[ $currency ], $value );
		}

		return $converted;
	}


	/**
	 * @param array $currencies
	 * @param int   $base_value
	 *
	 * @access internal
	 * @return array
	 */
	protected function _exchange_to_cash_single( array $currencies, $base_value ) {

		$results = array();

		foreach ( $currencies as $currency => $c_value ) {

			$results[ $currency ] = $base_value * $c_value;
		}

		return $results;
	}


	/**
	 * Convert amount of digital currencies list cash
	 *
	 * @param array $cash_list
	 *
	 * @return array
	 */
	public function exchange_to_digital( array $cash_list ) {

		$cash_list = array_map( 'strtoupper', $cash_list );

		if ( ! $prices = $this->prices() ) {
			return FALSE;
		}

		$converted = array();

		foreach ( $cash_list as $cash => $cash_value ) {

			foreach ( $prices as $d_currency => $d_values ) {

				if ( ! isset( $d_values[ $cash ] ) ) {
					continue;
				}

				$converted[ $d_currency ][ $cash ] = $cash_value / $d_values[ $cash ];
			}
		}

		return $converted;
	}


	/**
	 * @param string $id
	 *
	 * @return string
	 */
	protected function get_name( $id ) {

		$file_path = BS_Financial_Pack_Pro::dir_path( 'includes/data/all-cryptocurrencies.json' );

		if ( preg_match(
			'# "' . preg_quote( $id, '#' ) . '"\s*\:\s* \{ .*? "name"\s*:\s*"(.*?)" #isx',
			file_get_contents( $file_path ), $m )
		) {

			return $m[1];
		}

		return '';
	}
}
